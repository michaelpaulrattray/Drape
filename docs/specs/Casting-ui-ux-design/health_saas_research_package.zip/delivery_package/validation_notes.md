# Primary-Source Validation Notes

## Direct and adjacent competitors

### Guava Health

Guava’s current official site positions it as a broad personal health tracker for managing chronic illness, caring for others, seeking a diagnosis, and general health. It explicitly offers multi-provider record aggregation, symptom/medication/lifestyle tracking, correlations and treatment comparisons, printable visit summaries, PDF/photo lab extraction, searchable health history, and connections to patient portals and consumer devices. The official site states that it follows HIPAA and other applicable laws, does not sell user data, and gives users sharing control. Its current U.S. App Store listing adds AI summarization of doctor notes, natural-language health-data assistance, CCDA/DICOM/PDF/image imports, medical-record synchronization, co-occurrence/correlation views, and doctor-visit preparation. This means **record aggregation, correlations, AI summaries, data search, and appointment preparation are not whitespace**. The possible gap must be narrower: transparent evidence retrieval, causal-hypothesis discipline, knowledge-graph provenance, and structured experiment governance have not been verified in Guava’s public materials.

Sources:
- https://guavahealth.com/
- https://apps.apple.com/us/app/guava-health-tracker/id1622255863
- https://mobile.va.gov/app/guava-health-tracker

The U.S. Department of Veterans Affairs lists Guava as a third-party connected app and emphasizes that its descriptive claims come from the developer and are not VA endorsement or verification. That caveat should be preserved when using the VA page as corroboration.

### Bearable

Bearable’s official site confirms highly customizable symptom, mood, habit, treatment, and lifestyle logging; more than 30 reports; correlation views; experiments; goals; medication reminders; Apple/Google health-data integration; export/delete controls; and an explicit statement that it will not sell user data. Bearable therefore occupies the **customizable tracking + correlations + self-experimentation** territory. Public materials do not verify deep longitudinal medical-record ingestion, literature-linked pathway hypotheses, a medical knowledge graph, or a clinician collaboration workspace.

Source:
- https://bearable.app/

Representative chronic-illness community comments are anecdotal, not population evidence, but repeatedly illustrate a core design tension: users value customization and detail while also reporting setup burden, logging fatigue, overwhelm, and reduced usefulness when consistency drops. Some users report value from appointment snapshots and patterns, while others object to premium gating or find same-day correlations inadequate for delayed effects such as post-exertional malaise.

Sources:
- https://www.reddit.com/r/ChronicIllness/comments/1cougu4/does_anyone_have_experience_with_the_app_bearable/
- https://www.reddit.com/r/cfs/comments/1h9o0m7/any_symptom_pacing_app_advice_bearable_vs_visible/

### Visible

Visible explicitly focuses on Long COVID, ME/CFS, fibromyalgia, POTS, EDS, and other energy-limiting conditions. Its official product combines a Polar-manufactured continuous heart-rate band with pacing alerts, energy budgeting, HRV/resting-heart-rate trends, symptom/medication logging, provider reports, educational resources, and optional research participation. Visible explicitly states that it is not a medical device and does not diagnose, cure, mitigate, prevent, or treat disease. It is a strong example of a **condition wedge with passive sensing and a narrow, legible job-to-be-done**, but it is not publicly presented as a comprehensive longitudinal personal health record.

Source:
- https://www.makevisible.com/

### Human Health

Human Health’s official site positions the app as a “personal health lab” for chronic and unexplained conditions. It offers symptom and treatment tracking, AI-assisted pattern detection, owned medical history, provider communication, wearable/vitals inputs, research participation, and paid storage/reports. This is close to the proposed narrative, so generic claims about “AI patterns for chronic illness” or “personal health lab” are not differentiators. Public materials reviewed did not verify comprehensive multi-EHR aggregation, explicit peer-reviewed literature retrieval for every hypothesis, or a provenance-rich pathway graph.

Source:
- https://www.human.health/

### CareClinic

CareClinic’s official site confirms comprehensive symptom, medication, vital, lifestyle, record, and device tracking; provider/caregiver sharing; searchable storage for labs, vaccines, and imaging; Apple Health/Google Fit and device integrations; validated assessments; and guided pathways based on stated clinical frameworks. It markets personalized insights and evidence-based care plans. Consequently, “guided pathways,” “evidence-based content,” record storage, and provider reports are occupied territory. Any differentiated pathway explorer must show stronger evidence provenance, uncertainty, counter-hypotheses, and safeguards rather than simply offering more assertive recommendations.

Source:
- https://careclinic.io/

### Heads Up Health

Heads Up Health is practitioner-first and currently markets an AI-powered clinical-intelligence platform for integrative, functional, concierge, and longevity practices. It aggregates wearables, labs, diagnostics, EHRs, symptoms, nutrition, and other data; offers a practitioner portal, client companion app, AI copilot, customizable agents, alerts, reports, APIs/SDKs, and branded deployment. This invalidates any broad claim that practitioners lack multi-source health-data aggregation with AI. The remaining opportunity is more specifically a **consumer-controlled, safety-conservative, evidence/provenance-first personal knowledge system** that can hand clinicians a concise review artifact without forcing them to adopt a full practice platform.

Source:
- https://headsuphealth.com/product/

### User-review caution

A current Trustpilot page for Guava contains only four reviews and explicitly warns that reviews may not be representative. One detailed negative review alleges wearable-sync and vaccine-extraction discrepancies; Guava’s response explains delayed synchronization and acknowledged that document extraction performs best on labs and may mis-map vaccines. This is weak but useful qualitative evidence that **data provenance, reconciliation, extraction confidence, and correction workflows** are product-critical. It should not be generalized as a prevalence estimate.

Source:
- https://www.trustpilot.com/review/guavahealth.com

## United States FDA boundary

The FDA’s January 2026 Clinical Decision Support Software guidance clarifies the four statutory criteria for non-device CDS and emphasizes that existing digital-health policies continue to apply to software intended for patients or caregivers. The FDA FAQ states that simple tools that let patients organize, record, show, or communicate health information to clinicians are not medical devices. It also states that the non-device CDS exclusion is not the only relevant policy and that software may contain both device and non-device functions. Time-critical decision support generally cannot qualify as non-device CDS because users cannot independently review the basis in time.

The FDA’s January 2026 General Wellness guidance states that software intended to maintain or encourage a healthy lifestyle **unrelated to diagnosis, cure, mitigation, prevention, or treatment of disease** is outside the device definition. This is a poor fit for a product expressly designed around chronic-condition “root causes” unless wording and function are constrained carefully.

The FDA’s current mobile/device-software page says oversight is function-specific and risk-based. It lists patient self-management software without specific treatment suggestions among functions for which FDA may exercise enforcement discretion. The page also encourages early contact with FDA about risk and premarket requirements.

Primary sources:
- https://www.fda.gov/regulatory-information/search-fda-guidance-documents/clinical-decision-support-software
- https://www.fda.gov/medical-devices/software-medical-device-samd/clinical-decision-support-software-frequently-asked-questions-faqs
- https://www.fda.gov/regulatory-information/search-fda-guidance-documents/general-wellness-policy-low-risk-devices
- https://www.fda.gov/medical-devices/digital-health-center-excellence/device-software-functions-including-mobile-medical-applications

### Regulatory implication

A disclaimer is not a safe harbor. The FDA analysis turns on intended use and software function, including marketing, outputs, users, and whether recommendations are independently reviewable. A consumer-facing feature that ranks possible causes, interprets patient-specific labs/signals, and recommends tests, supplements, diets, or treatment changes can plausibly move toward device functionality or at least higher liability exposure. The safer initial form is an **evidence navigator and structured question generator** that (1) summarizes user-entered facts, (2) displays non-causal correlations and data quality, (3) retrieves and quotes relevant literature, (4) shows multiple competing hypotheses without ranking a diagnosis, (5) explains why each source may or may not apply, (6) blocks time-critical use, and (7) produces questions for a clinician rather than a treatment plan. Formal U.S. regulatory counsel and, if needed, an FDA Q-Submission should precede launch of personalized pathway ranking.

## U.S. consumer-health privacy and advertising obligations

The FTC’s current Health Breach Notification Rule guidance states that many consumer health apps are outside HIPAA but remain subject to the FTC Act and the Health Breach Notification Rule. A company is likely a vendor of personal health records when it offers or maintains an electronic record of identifiable health information that can draw from multiple sources and is managed, shared, or controlled primarily for the individual. The proposed product—combining user inputs, wearables, records, and external sources—fits that fact pattern closely. The July 2024 amendments expressly clarified coverage of health apps and connected devices. A “breach” can include unauthorized disclosure, not merely hacking, and the rule has consumer, FTC, and sometimes media notification requirements.

HHS’s April 2026 health-app resources reinforce that HIPAA applies only in particular covered-entity/business-associate relationships; a direct-to-consumer app can hold health information originating from a hospital without becoming HIPAA-covered merely for that reason. Calling the app “HIPAA compliant” without a role-specific analysis is therefore potentially misleading. The joint FTC/HHS/FDA interactive tool says multiple regimes may apply simultaneously, including the FTC Act, Health Breach Notification Rule, HIPAA, FD&C Act, COPPA, and information-blocking rules. The FTC Act prohibits unfair or deceptive privacy, security, safety, performance, and health claims. FTC health-claims guidance requires appropriate substantiation for health-related advertising claims.

Primary sources:
- https://www.ftc.gov/business-guidance/resources/complying-ftcs-health-breach-notification-rule-0
- https://www.hhs.gov/hipaa/for-professionals/special-topics/health-apps/index.html
- https://www.ftc.gov/business-guidance/resources/mobile-health-apps-interactive-tool
- https://www.ftc.gov/business-guidance/advertising-marketing/health-claims

### Product implications

The launch plan should treat privacy and substantiation as **product architecture**, not footer language. It should include data minimization, explicit purpose-bound consent, no ad-tech SDKs touching health events, end-to-end data-flow mapping, role-specific HIPAA analysis, a Health Breach Notification Rule incident process, deletion/export controls, separate consent for research use, evidence for every performance or health-benefit claim, and a ban on dark patterns. “We never sell data” is necessary but insufficient because unauthorized disclosures to analytics or advertising vendors can independently create FTC exposure.

## Market denominator and equity constraints

A 2025 peer-reviewed CDC analysis of 2013–2023 Behavioral Risk Factor Surveillance System data estimated that in 2023, 76.4% of U.S. adults—about 194 million people—reported at least one of 12 selected chronic conditions, while 51.4%—about 130–131 million—reported two or more. The prevalence of multiple chronic conditions was 27.1% among adults aged 18–34, 52.7% among those aged 35–64, and 78.8% among adults aged 65 or older. These numbers establish a large problem population but **must not be labeled TAM revenue**: only a subset has the digital access, motivation, condition complexity, privacy comfort, and willingness to pay for a longitudinal self-management product.

The CDC also reports that chronic conditions are leading drivers of U.S. health-care costs and that affected communities can face substantial socioeconomic, insurance, transportation, and care-access constraints. A 2024 CDC analysis found higher chronic-disease burden in areas with lower income, lower educational attainment, higher uninsured rates, and longer travel distances to care. This creates a strategic conflict: the people with the greatest need may have the least ability to pay or sustain high-effort logging. A premium-only, high-manual-input product risks selecting for affluent quantified-self users rather than solving the stated chronic-illness problem.

Primary sources:
- https://www.cdc.gov/pcd/issues/2025/24_0539.htm
- https://www.cdc.gov/chronic-disease/about/index.html
- https://www.cdc.gov/pcd/issues/2024/23_0267.htm

### Market-sizing implication

Use a bottom-up three-layer model rather than commercial market-report headlines: (1) **need population** = adults with multiple conditions or persistent unexplained symptoms; (2) **reachable early-adopter population** = digitally engaged people already tracking symptoms, using wearables/portals, and seeking appointment support; and (3) **paying serviceable market** = early adopters with enough willingness and ability to pay, or whose plan/provider/employer/research sponsor pays. Base-case revenue should be built from acquisition-channel capacity, activation, retention, and willingness-to-pay experiments—not by multiplying 130 million people by a subscription price.

## Scientific limits of correlations, N-of-1 methods, and wearables

A peer-reviewed methodological paper on self-tracked time-series data distinguishes observational N-of-1 studies from randomized N-of-1 trials. It argues that observational associations can generate candidate causal hypotheses, but valid causal interpretation depends on explicit, critically assessed assumptions about the data-generating process. The framework must address autocorrelation, underlying trends, delayed onset or decay, and carryover effects. A newer formal treatment of N-of-1 causal inference reaches the same practical conclusion: even randomized within-person crossover studies require careful handling of time-varying common causes, outcome history, carryover, and trends; different assumptions lead to different estimators and interpretations.

A peer-reviewed review of wearables in clinical trials emphasizes that dense, real-world data are promising but require **analytical validation and clinical validation for the specific context of use**. Consumer sensor values are not interchangeable with validated clinical endpoints merely because they are continuous or precise-looking.

Sources:
- https://pmc.ncbi.nlm.nih.gov/articles/PMC6087468/
- https://arxiv.org/html/2406.10360v2
- https://pmc.ncbi.nlm.nih.gov/articles/PMC6032822/

### Product implications

The SaaS should implement an explicit evidence ladder:

1. **Observation:** a data-quality-qualified time series or event.
2. **Association:** a non-causal relationship with sample size, missingness, lag window, effect estimate, and uncertainty.
3. **Hypothesis:** a proposed explanation linked to supporting and contradicting literature.
4. **Experiment candidate:** only for low-risk, reversible behaviors and only after screening contraindications and confounding risks.
5. **Structured N-of-1 protocol:** predefined outcome, baseline, comparison, duration, washout/carryover assumptions, stop rules, and preferably clinician review when medically relevant.
6. **Result:** interpreted as individual and context-specific, with no automatic generalization.

The interface must never turn a correlation coefficient into “X caused Y.” It should display sensitivity to different lag windows and missing-data choices, label exploratory analyses, correct or warn for multiple comparisons, and refuse experiments involving medication changes, dangerous restriction, pregnancy, severe symptoms, or other high-risk scenarios without clinician oversight.

## Interoperability feasibility and constraints

Official standards documentation confirms that SMART App Launch uses OAuth 2.0 patterns, scoped permissions, capability discovery, and FHIR resources for user-facing apps and backend services. CMS requires affected payers to expose maintained claims, encounter, and clinical data—including labs—through conformant FHIR-based Patient Access APIs, but it does not require them to convert every unstructured PDF or fax into discrete FHIR elements. Therefore, “connect all my records” is feasible only as a **multi-route ingestion strategy**, not a single universal API.

Apple HealthKit is a permissioned repository on Apple devices. Applications access health and fitness data through the local HealthKit store and must handle changes to data, sources, deletions, and permissions. Android Health Connect likewise stores structured fitness and health records with user-controlled permissions; its newer Medical Records feature uses FHIR. Google states that legacy Google Fit APIs remain supported only through the end of 2026, which creates a concrete migration risk.

Primary sources:
- https://build.fhir.org/ig/HL7/smart-app-launch/
- https://www.cms.gov/priorities/burden-reduction/overview/interoperability/frequently-asked-questions/patient-access-api
- https://developer.apple.com/documentation/healthkit
- https://developer.android.com/health-and-fitness/health-connect

### Architecture implications

The ingestion layer should preserve **source, timestamp, original unit, normalized unit, device or institution, parser version, consent scope, and confidence** for every datum. The realistic order is: (1) HealthKit and Health Connect for device data; (2) user-authorized FHIR connections for payer/provider records; (3) structured CSV/JSON imports; (4) documents with OCR and explicit human verification; and (5) manual entry. The MVP should not promise nationwide record completeness. It should disclose connection coverage, unsupported document types, data freshness, and missingness. OCR-extracted labs must remain visibly provisional until the user verifies the test name, value, unit, reference range, specimen date, and source document.

## Current official pricing benchmarks

As accessed on 31 July 2026, Guava lists a free plan with portal record sync, device sync, tracking, trends/correlations, sharing, and document upload; Premium is listed at **US$8/month or US$78/year** and adds automatic insights, lab-result extraction, an AI assistant, emergency card, and family/caregiver features. Bearable’s official pricing article lists a free tier and Premium at **US$6.99/month or US$34.99/year**, with frequent annual discounts; because the page was originally published in 2020, final publication should label the figure as the current amount displayed on that page rather than assuming universal in-app-store pricing. Heads Up Health no longer publishes a fixed amount on its professional pricing page and requests custom packaging and pricing. PicnicHealth lists membership at **US$499/year**, free during eligible research participation, and a Connected Care visit at **US$149 per visit**, potentially lower with insurance.

Primary sources:
- https://guavahealth.com/plans
- https://bearable.app/our-pricing-and-principles/
- https://headsuphealth.com/pro-pricing/
- https://picnichealth.com/pricing

### Pricing implication

Basic tracking and aggregation face a strong free-to-low-cost benchmark, while high-touch record collection, research sponsorship, and clinician review support materially higher prices. The proposed product should test a low-friction free organizational layer, a one-time appointment-preparation outcome, and a recurring evidence workspace rather than assuming one subscription price fits all jobs.
