# Strategic Synthesis: Personal Health “Second Brain” SaaS

**Prepared by:** Manus AI  
**Status:** Research synthesis for planning; not medical, legal, or regulatory advice

## Executive decision

The original concept addresses a real and large problem, but its broad framing is **not differentiated enough to launch**. Guava already combines record aggregation, tracking, correlations, AI-assisted summaries, data search, and appointment preparation. Human Health uses the “personal health lab” narrative and AI-assisted pattern detection. Bearable offers customizable tracking, correlations, and experiments. CareClinic offers guided pathways and evidence-oriented care plans. Visible demonstrates the power of a narrow condition wedge with passive monitoring, while Heads Up Health supplies multi-source data aggregation and AI to practitioners.

The defensible opportunity is therefore not “all health data in one place,” “AI finds patterns,” “a root-cause explorer,” or “a doctor-ready report.” Those territories are occupied. The most credible opportunity is a narrower product:

> **A provenance-first, safety-conservative evidence navigator that turns fragmented longitudinal data into a clinician-reviewable health story, competing hypotheses, and structured questions—without diagnosing, ranking root causes, or recommending treatment.**

The recommended initial wedge is **complex-care visit preparation for adults with post-viral, dysautonomia, fatigue, and overlapping multi-system symptoms**. The job-to-be-done is narrower than diagnosing these conditions: users need to reconstruct a reliable timeline, identify data-quality-qualified patterns, retrieve applicable evidence, and prepare a concise specialist discussion packet. This cohort has high longitudinal-data density and active communities, but also low energy, privacy sensitivity, and modest willingness to pay. The product must therefore minimize manual logging, avoid medical overclaiming, and validate a hybrid D2C/clinic or advocacy-partner model rather than assuming a pure subscription business will work.

## What is already occupied

| Claimed value proposition | Market reality | Strategic consequence |
|---|---|---|
| “Unify my records, labs, symptoms, and wearables” | Guava and practitioner platforms already aggregate multiple health-data classes; several competitors connect devices and store records. | Aggregation is a required capability, not a differentiated promise. |
| “Find correlations and patterns” | Guava, Bearable, Human Health, CareClinic, and others market correlations, patterns, or personalized insights. | A correlation engine alone will be commoditized and can amplify false causal beliefs. |
| “Help me prepare for my doctor” | Guava, Human Health, Visible, and CareClinic offer reports or visit-support outputs. | The advantage must be report quality, evidence provenance, brevity, and clinician acceptance. |
| “Guide me through root causes or pathways” | CareClinic markets guided pathways; symptom checkers and functional-medicine tools already suggest possibilities. | “Root cause” is crowded, medically risky, and likely to invite regulatory scrutiny. |
| “Protect my privacy and never sell my data” | Several competitors make privacy and no-sale claims. | Privacy must be technically and contractually demonstrable, not a slogan. |
| “Use AI as a personal health assistant” | Multiple competitors now market AI summaries, copilots, or pattern detection. | AI is an implementation layer, not the category or moat. |

## The strongest plausible gaps

The gaps below are based on public product materials and independent qualitative evidence. “Not publicly verified” does not mean a competitor cannot do it; product demonstrations and win/loss interviews are required before treating any gap as proven.

| Potential gap | Why it matters | Publicly visible competitive coverage | Defensibility potential | Validation need |
|---|---|---:|---:|---|
| Sentence-level evidence provenance for each personalized claim | Users and clinicians need to inspect the source, applicability, date, study type, and contradictions. | Low or not verified | High if paired with a quality/evaluation system | Test whether clinicians trust and use it rather than seeing it as information overload. |
| Explicit separation of observation, association, hypothesis, and causal result | Prevents a chart or model from converting coincidence into a health claim. | Low or not verified | Medium–high through methodology and UX | Test comprehension and whether warnings reduce false confidence. |
| Lag-aware, missingness-aware longitudinal analysis | Many chronic symptoms follow delayed or cumulative exposures; same-day correlations are often misleading. | Partial in some trackers; rigor not verified | Medium | Benchmark against pre-specified analyses and expert statistical review. |
| Data lineage and reconciliation | Conflicting wearable values, duplicated records, OCR errors, and changing reference ranges can corrupt downstream insights. | Mostly invisible to users | High through trustworthy ingestion and correction workflows | Measure extraction accuracy, correction burden, and provenance comprehension. |
| Governed low-risk N-of-1 protocols | Users already self-experiment, often without washout, stop rules, or confounder controls. | “Experiments” exist, but rigorous governance is not verified | Medium–high if clinically reviewed | Restrict scope and test with an ethics/safety framework before launch. |
| Dual-audience evidence packet | Patients need agency; clinicians need a brief, source-linked, non-diagnostic artifact that fits workflow. | Reports exist, but clinician acceptance is not established | High through templates, workflow validation, and partner distribution | Conduct blinded clinician review and real-visit studies. |
| Privacy architecture without ad-tech or hidden secondary use | Consumer health apps face FTC breach and deception exposure even when HIPAA does not apply. | Privacy claims are common; architecture is rarely transparent | High as a trust moat, but costly | Test whether privacy materially affects conversion and retention. |
| Contradiction-aware literature retrieval | Medical evidence is heterogeneous; presenting only confirming papers can reinforce health anxiety and self-diagnosis. | Not publicly verified | High if reliably evaluated | Build a benchmark with guideline and evidence-review experts. |

## Recommended positioning

The product should be positioned around a concrete outcome rather than a metaphorical category.

| Element | Recommendation |
|---|---|
| Category | **Personal health evidence and visit-preparation workspace** |
| Primary user | An adult managing persistent multi-system symptoms across several clinicians, portals, documents, and wearable sources |
| Initial cohort | Post-viral illness, dysautonomia/POTS, fatigue or exertion intolerance, and overlapping multi-system symptoms |
| Core job | “Help me turn months of scattered data into a reliable timeline, patterns I can inspect, evidence I can understand, and questions a clinician can review.” |
| Primary output | A one- to two-page clinician packet plus an inspectable evidence appendix |
| Promise | Better organization, traceability, and preparation—not diagnosis, root-cause discovery, treatment selection, or emergency triage |
| Proof | Ingestion accuracy, source provenance, clinician usefulness, reduced preparation time, and fewer factual corrections |
| Tone | Calm, conservative, non-alarmist, and explicit about uncertainty |

A suitable working message is: **“Bring your health story into focus—without turning correlations into conclusions.”** The phrase “root cause” should not appear in launch marketing. “Second brain” can remain an internal product metaphor, but it is too broad and too close to competitor narratives to be the public positioning.

## Why a job-based wedge is preferable to a disease app

A disease-specific app can acquire users through concentrated communities, but it narrows clinical relevance and can pressure the product toward medical claims. A purely horizontal personal health record has a larger theoretical market but weak differentiation and a difficult activation problem. The recommended approach combines both: launch around one **job**—complex-care visit preparation—inside one **cohort** with high need and dense longitudinal data. If validated, the same workflow can expand into migraine, digestive disorders, autoimmune conditions, and women’s health without claiming to diagnose any of them.

| Candidate wedge | Need intensity | Competitive crowding | Passive-data fit | Ability to acquire through communities | Safety/regulatory complexity | Overall assessment |
|---|---:|---:|---:|---:|---:|---|
| Post-viral illness, POTS, ME/CFS, fatigue | Very high | Medium; Visible is strong in pacing | High | High | High | Best cohort for testing the longitudinal-evidence workflow, provided manual burden is minimal. |
| Migraine | High | High; many dedicated trackers | High | High | Medium–high | Easier measurement but harder differentiation. |
| Digestive symptoms/IBS | High | High; food and symptom trackers are established | Medium | High | High due restrictive-diet and causal-claim risks | Attractive later, not the safest first wedge. |
| Eczema | Medium–high | Medium | Medium | Medium | Medium–high | Visual data can help, but the cross-record “second brain” need is weaker. |
| Broad autoimmune or women’s health | Very high | High and fragmented | Medium–high | High | Very high, with sensitive-data and bias concerns | Too broad for the first cohort. |
| Generic quantified self/longevity | Medium | Very high and affluent | Very high | Medium | Medium | Better willingness to pay but misaligned with the chronic-illness mission and crowded by biomarker platforms. |

## Minimum viable product boundary

The MVP should prove that a user can create a trustworthy clinical story with less effort and that a clinician finds the result useful. It should not attempt to build the full “health operating system.”

| Include in MVP | Reason |
|---|---|
| Lightweight timeline with symptoms, medications, diagnoses, procedures, and user-defined events | Establishes the longitudinal spine and immediate utility. |
| Apple HealthKit and Android Health Connect import | Reduces manual burden and supports passive baselines. |
| PDF/image lab and record import with mandatory verification | Addresses fragmentation while treating OCR as provisional. |
| Provenance, unit normalization, duplicate detection, and correction history | Trust must be designed into the data layer. |
| Sparse/adaptive check-ins rather than large daily forms | The initial cohort may have severe fatigue and cognitive burden. |
| Descriptive trends and lag-aware associations with data-quality and uncertainty labels | Provides insight without asserting causality. |
| Evidence cards sourced from peer-reviewed literature and authoritative guidance | Makes the output inspectable and supports question formation. |
| Competing-hypothesis workspace that does not rank diagnoses | Helps users organize questions while remaining safety-conservative. |
| Clinician packet with timeline, medications, changes, key trends, user goals, and questions | Creates a testable high-value outcome. |
| Export, deletion, consent controls, access log, and no advertising SDKs | Minimum trust and compliance architecture. |

| Explicitly exclude from MVP | Reason |
|---|---|
| Diagnosis, probability scores, or ranked “root causes” | High clinical and regulatory risk; weakly supported by noisy personal data. |
| Medication, supplement, fasting, elimination-diet, or treatment recommendations | Can cause direct harm and crosses the intended product boundary. |
| Emergency or time-critical triage | A consumer evidence workspace is not an emergency system. |
| Autonomous test ordering or interpretation | Introduces clinical workflow, liability, and regulated-function risk. |
| Full nationwide EHR coverage | Integration coverage is uneven and expensive; overpromising would damage trust. |
| Genetics, microbiome, and broad biomarker optimization | Expands complexity before the core workflow is validated. |
| Community diagnosis matching | Risks misinformation, privacy leakage, and reinforcement of unverified beliefs. |
| Employer-facing individual analytics | Creates surveillance and discrimination concerns at the most trust-sensitive stage. |
| Monetization of identifiable or “de-identified” health data | Conflicts with trust positioning and creates re-identification and consent risk. |

## Safety model

The product should implement a visible evidence ladder. An item can move upward only when the required design, data quality, and review conditions are satisfied.

| Level | Permitted output | Required safeguards |
|---|---|---|
| Observation | “Heart rate and fatigue entries increased during this period.” | Source and device shown; missingness and data quality displayed. |
| Association | “Higher activity days were followed by higher fatigue entries 24–48 hours later in this dataset.” | Sample size, lag choice, effect estimate, uncertainty, multiple-testing warning, no causal wording. |
| Hypothesis | “Several mechanisms could be relevant to discuss; evidence is mixed.” | Multiple hypotheses, contradicting evidence, applicability limits, no diagnostic ranking. |
| Low-risk experiment candidate | “A consistent bedtime could be tested as a reversible behavior.” | Contraindication screen, predefined outcome, stop rules, limited scope, no medication or restrictive intervention. |
| Clinician-reviewed protocol | A structured N-of-1 plan | Clinician involvement where medically relevant, washout/carryover assumptions, pre-specified analysis, adverse-event capture. |
| Result | Individual, context-specific finding | No population generalization; sensitivity analysis and uncertainty retained. |

The product must include red-flag pathways for severe or time-critical symptoms, but these should be simple deterministic redirects to emergency or professional care rather than probabilistic AI triage. The app should prevent users from interpreting silence as reassurance.

## Privacy and security strategy

“End-to-end encrypted AI” is technically inconsistent unless inference happens on the user’s device, in a carefully designed trusted execution environment, or after explicit client-side decryption. The initial product should not make a zero-knowledge claim it cannot keep. A credible MVP promise is narrower: encryption in transit and at rest, field-level protection for especially sensitive values, strict tenant isolation, least-privilege access, short-lived processing credentials, auditable access, no advertising SDKs, no sale of data, explicit secondary-use consent, and reliable export/deletion.

The architecture should record source, original value and unit, normalized representation, timestamp, institution or device, parser version, confidence, verification status, and every correction. Health data should be separated from product analytics, and health events should not flow into general advertising or behavioral analytics systems. A data-protection impact assessment, incident plan under the FTC Health Breach Notification Rule, state-law review, and role-specific HIPAA analysis are launch prerequisites.

## Technical architecture principles

| Layer | Recommended approach | Key constraint |
|---|---|---|
| Client | Mobile-first capture with a web companion | HealthKit and Health Connect access are device-centric; offline and low-energy use matter. |
| Canonical data model | FHIR-compatible, event-oriented model with a personal ontology layer | Preserve original data; do not force all user observations into false clinical precision. |
| Ingestion | HealthKit/Health Connect, authorized FHIR, structured files, then OCR/manual entry | Coverage, freshness, and completeness must be disclosed per source. |
| Identity and consent | Granular scopes, revocation, purpose limitation, and access logs | Consent must be separate for care support, research, and product improvement. |
| Analytics | Descriptive statistics first; pre-specified lag analysis and robust missingness handling | Avoid automated causal inference claims from observational data. |
| Literature retrieval | Curated authoritative sources plus peer-reviewed literature, with source snapshots and citation verification | Retrieval-augmented generation reduces but does not eliminate hallucination. |
| Hypothesis representation | Knowledge graph that separates user observations, clinical facts, hypotheses, and evidence edges | The graph must encode contradiction, uncertainty, date, and provenance. |
| AI output | Template-constrained generation with deterministic policy checks and citation entailment checks | High-risk outputs must be blocked rather than softened by disclaimers. |
| Reporting | One-page summary with inspectable appendix | Clinicians have limited time; completeness must not become clutter. |
| Evaluation | Fixed safety, factuality, citation, bias, ingestion, and usability benchmarks | Model updates should not ship without regression testing and auditability. |

## Business model recommendation

A pure D2C subscription is possible but should not be assumed. The target cohort has high need but may have limited energy and purchasing power. Employers offer volume but introduce trust and procurement problems. Life-sciences data monetization conflicts with the privacy position. The most aligned early model is **D2C validation plus clinic, advocacy, or research-cohort sponsorship**, with strict separation between care-support use and research consent.

| Model | Strength | Weakness | Recommendation |
|---|---|---|---|
| D2C subscription | Fast feedback and direct user relationship | Low willingness to pay, high churn, expensive acquisition | Test, but do not build the plan around subscription assumptions. |
| One-time visit-preparation pack | Concrete value event and easier willingness-to-pay test | Episodic revenue and possible seasonality | Strong first paid experiment. |
| Specialty-clinic seat or per-active-patient fee | Clear workflow ROI and repeat distribution | Requires clinician trust and integration; sales cycles | Best second channel after report validation. |
| Advocacy-group sponsorship | Trust and concentrated reach | Limited budgets and governance requirements | Strong acquisition and co-design channel. |
| Research-cohort licensing | Funds integrations and evidence generation | Consent, data-rights, and protocol complexity | Later, with independent governance and explicit opt-in. |
| Employer or payer contracts | Scale and potential budget | Surveillance concerns, long cycles, unclear early ROI | Defer until outcomes and privacy boundaries are proven. |
| Data brokerage or advertising | Revenue without subscription | Directly undermines trust and creates regulatory exposure | Reject. |

Pricing should be tested rather than fixed in the plan. Current competitive signals suggest a low consumer subscription ceiling for basic tracking. Three concepts should be tested: a free organizational tier; a paid appointment pack; and a recurring evidence workspace. The appointment pack can reveal whether users will pay for a concrete outcome before the company commits to a subscription-heavy model.

## Market-size method

The 2025 CDC analysis estimates roughly 130–131 million U.S. adults with two or more selected chronic conditions. This is a **need denominator**, not a revenue TAM. A defensible market model should not multiply that figure by a subscription price.

The operating model should be built from channels:

> **Qualified audience reached × activation rate × report-completion rate × paid conversion × annual revenue per paying user = obtainable annual revenue.**

For example, the plan should specify the number and size of partner communities, clinic cohorts, creator audiences, and paid-acquisition tests; then use observed conversion and retention. Every percentage should be labeled as measured, benchmarked, or assumed. Until primary research is complete, the SAM and SOM should be expressed as formulas and ranges rather than a headline valuation.

## Go-to-market sequence

| Stage | Primary channel | Offer | Evidence goal |
|---|---|---|---|
| 0. Discovery | Condition communities, advocacy groups, specialty-clinic staff | Interviews and record-workflow observation | Confirm the problem, language, trust barriers, and current workarounds. |
| 1. Concierge pilot | 20–30 patients preparing for a real visit | Manually assisted timeline and evidence packet | Test usefulness, errors, preparation time, and willingness to pay. |
| 2. Clinician validation | Primary-care and relevant specialists | Blinded review of structured reports | Test clinical readability, omission risk, and time saved. |
| 3. Closed product pilot | One or two communities and two to five clinics | Self-service ingestion, timeline, and report | Measure activation, correction burden, repeat use, and safety incidents. |
| 4. Paid launch | D2C appointment pack plus selected clinic partners | Concrete report outcome | Establish conversion, retention, support cost, and channel economics. |
| 5. Expansion | Adjacent condition communities and research partners | Reusable workflow with condition-specific evidence modules | Test portability without broadening medical claims. |

Condition communities should be involved as paid research partners rather than merely mined for acquisition. Clinicians should be compensated for design review. User-generated health stories must not be used in marketing without explicit, revocable consent.

## Validation experiments and proposed gates

The thresholds below are planning gates, not industry facts. They should be adjusted with clinical, regulatory, and statistical advisors before being treated as acceptance criteria.

| Question | Experiment | Proposed evidence gate |
|---|---|---|
| Is the problem acute enough? | At least 30 interviews across high-tracking patients, low-energy patients, caregivers, and clinicians | At least 70% of qualified users independently describe timeline reconstruction or visit preparation as a recurring high-friction problem. |
| Can the core value be delivered before software? | Concierge creation of 20–30 real visit packets | At least 70% of users say the packet materially improved preparation; fewer than 5% of facts require material correction after verification. |
| Will clinicians use the output? | Blinded review and real-visit observation | At least 70% rate the packet useful or very useful; no critical safety omission; median review time at or below two minutes for the summary page. |
| Is ingestion trustworthy? | Benchmark on consented real records from multiple formats and sources | Greater than 99% accuracy for verified critical fields after user review; every datum traceable to its source; correction process understandable to at least 90% of usability-test participants. |
| Is burden low enough for the cohort? | Eight-week closed pilot | Median active logging burden below two minutes per day; at least 50% of activated users still contribute or review data in week eight. |
| Does the analysis avoid false confidence? | Comprehension test comparing alternative uncertainty interfaces | At least 85% correctly distinguish association from causation and can identify data-quality limitations. |
| Is there willingness to pay? | Test one-time pack and recurring workspace offers with qualified users | A pre-specified paid conversion threshold is met without deceptive urgency; report willingness separately by payer type and income band. |
| Does AI remain inside policy? | Adversarial safety benchmark and expert review | Zero unblocked high-severity outputs involving diagnosis, medication changes, dangerous restriction, emergency reassurance, or fabricated citations before launch. |
| Is the channel viable? | Two community pilots and two clinic pilots | Measured acquisition cost and support cost fit a credible payback period; partner trust remains intact. |

## Moat strategy

The moat should not be “we have an LLM” or “we have more health data.” Models are replaceable, and health data accumulation can become a liability. A credible moat combines five assets: a high-quality normalized longitudinal data layer with provenance; a clinician-validated report format; a contradiction-aware evidence graph; a safety and evaluation system with versioned benchmarks; and trusted distribution through communities and specialty practices. Over time, consented and governed outcome data can improve relevance, but it must not depend on hidden secondary use.

## Critical risks and kill conditions

| Risk | Early warning | Mitigation | Kill or pause condition |
|---|---|---|---|
| False diagnosis or treatment influence | Users interpret hypotheses as conclusions or change care without review | Remove ranking, use evidence ladder, block high-risk outputs, conduct comprehension testing | Any severe unmitigated harm or repeated inability to prevent unsafe interpretation. |
| Regulatory reclassification | Marketing or features imply diagnosis, monitoring, or treatment selection | Function-by-function counsel review; consider FDA engagement before personalized ranking | Counsel concludes the intended MVP cannot operate within the chosen risk and capital envelope. |
| Privacy breach or unauthorized disclosure | Health events appear in general analytics, logs, support tools, or third-party SDKs | Data-flow inventory, isolated analytics, least privilege, breach response, vendor review | Any unresolved architecture that requires sharing identifiable health data for advertising or nonessential analytics. |
| Low adherence and logging fatigue | Users stop after setup or cannot maintain daily forms | Passive import, sparse adaptive prompts, value before logging, caregiver support | Week-eight engagement remains below the pre-specified gate after two materially different onboarding designs. |
| Clinician rejection | Reports are ignored, too long, inaccurate, or anxiety-amplifying | Co-design, one-page summary, provenance appendix, workflow studies | Clinicians cannot identify a repeatable use case or report increases visit burden. |
| Weak willingness to pay | High stated interest but low paid conversion | Test one-time outcome pricing and sponsored access | No payer segment supports credible unit economics after controlled pricing tests. |
| Data incompleteness | Users assume connected records are complete when they are not | Coverage map, freshness labels, reconciliation, explicit missingness | Product cannot reliably communicate source gaps or critical extraction accuracy. |
| Health anxiety and compulsive tracking | Increased checking, rumination, or symptom fixation | Calm defaults, limited notifications, wellbeing monitoring, pause mode | Meaningful evidence that the product worsens anxiety without an effective mitigation. |

## Recommendation to Claude Fable

The final plan should not begin with a full build roadmap. It should begin with a **validation program** and preserve three decision branches.

| Option | Description | When to choose |
|---|---|---|
| A. Concierge evidence-and-visit service | Humans assemble the timeline and evidence packet using minimal software. | Choose first to validate the job, output, safety boundary, and willingness to pay. |
| B. Consumer self-service workspace | Mobile/web product for ingestion, timeline, evidence, and reports. | Build only after Option A proves repeatable value and ingestion requirements. |
| C. Clinic-sponsored workflow | Practices invite patients and receive a concise packet. | Add after clinicians demonstrate time savings and a budget owner is identified. |

**Recommended sequence:** approve Option A as the validation vehicle; use its findings to scope Option B; introduce Option C only after clinician acceptance. Do not approve a broad root-cause platform, nationwide EHR integration, employer analytics, or treatment recommendations in the initial plan.

## Acceptance criteria for the final plan

The Claude Fable plan should be accepted only if it:

1. Reframes the product away from broad “root cause” and generic AI positioning.
2. Defines one job-based wedge and one initial cohort.
3. Distinguishes verified competitor capabilities from unverified gaps.
4. Makes the evidence ladder and safety policy product requirements.
5. Starts with concierge and clinician validation before substantial software investment.
6. Uses bottom-up channel economics rather than top-down market-report TAM.
7. Treats privacy, provenance, and consent as architecture.
8. Includes explicit exclusions, kill criteria, and regulatory review gates.
9. Separates assumptions from measured facts.
10. Provides a staged decision memo rather than presenting the entire vision as one MVP.
