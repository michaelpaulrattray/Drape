# Dossier Audit Report

- **Document:** `health_saas_market_research_dossier.md`
- **Body word count:** 9,148
- **Headings:** 43
- **Table rows detected:** 254
- **Inline citation occurrences:** 73
- **Unique cited references:** 47
- **Reference definitions:** 47
- **Local image assets:** 1

## Integrity checks

| Check | Result |
|---|---|
| Missing reference definitions | None |
| Unused reference definitions | None |
| Duplicate reference numbers | None |
| Missing numbers in reference sequence | None |
| Duplicate reference URLs | None |
| Missing local image assets | None |
| Missing required sections | None |

## Claim-labeling signals

| Signal | Count |
|---|---:|
| not publicly verified | 5 |
| assumption | 11 |
| proposed gate | 3 |
| confirmed | 12 |

## Overall result

**PASS** — structural and citation-integrity checks succeeded.

> This automated audit verifies document structure and citation wiring. It does not replace substantive source review, legal advice, clinical review, or hands-on competitor testing.
