# Health SaaS Wide-Research Scope

## Objective

Evaluate the commercial, product, clinical-safety, regulatory, privacy, technical, and go-to-market viability of a consumer-facing **personal health second brain** with linked records, longitudinal tracking, evidence-backed hypothesis generation, and a conservative Root Cause & Pathway Explorer. The output must identify what existing products do well, what they demonstrably do not do, which unmet needs are worth pursuing, and which attractive-looking opportunities should be avoided because of safety, regulatory, trust, or execution risk.

## Core decision questions

1. Which initial user segment and condition wedge has the strongest unmet need, willingness to pay, and manageable clinical risk?
2. Which competitors are genuinely direct, adjacent, or substitutes, and what claims can be made about their omissions based on current product evidence rather than inference?
3. Is a defensible gap available at the intersection of personal health records, self-tracking, evidence retrieval, knowledge graphs, and clinician collaboration?
4. What is the safest useful form of a pathway explorer before it becomes diagnosis, treatment recommendation, or regulated clinical decision support?
5. What should be in the MVP, what must remain human-supervised or practitioner-facing, and what should be deferred?
6. Which architecture and data-governance choices create trust without making the first release infeasible?
7. What monetization, distribution, and trust-building strategy can overcome high acquisition costs and skepticism in consumer health?
8. Which assumptions require validation interviews, prototype tests, regulatory counsel, or clinical pilots before investment?

## Confirmed parallel-research workstreams

The research will run across the following complete set of independent workstreams:

1. Chronic-illness user needs, jobs-to-be-done, current workarounds, trust barriers, and willingness-to-pay signals.
2. Patient-controlled longitudinal health-record and personal health record market landscape.
3. N-of-1 trials, quantified-self methods, symptom correlation, and limits of causal inference.
4. Guava Health competitor deep dive.
5. Bearable competitor deep dive.
6. CareClinic competitor deep dive.
7. Human Health competitor deep dive.
8. Visible competitor deep dive.
9. Heads Up Health competitor deep dive.
10. Exist.io, Flaredown, mySymptoms, and comparable correlation-tracking tools.
11. Ornament and comparable lab-result interpretation/tracking apps.
12. InsideTracker, Function Health, and consumer biomarker-personalization services.
13. PicnicHealth, Seqster, OneRecord, Apple Health Records, and health-record aggregation alternatives.
14. PatientsLikeMe, StuffThatWorks, Open Humans, and community/research substitutes.
15. Ada, K Health, Buoy, Healthily, and symptom-checker substitutes.
16. Practice Better, Fullscript, Rupa Health, and practitioner/functional-medicine workflow alternatives.
17. Obsidian, Notion, spreadsheets, and DIY personal-health knowledge-base substitutes.
18. Consumer reviews and complaint patterns for leading tracking and personal-health-record apps.
19. Competitive feature and pricing benchmarks across direct and adjacent products.
20. Evidence-search and medical-literature tools such as OpenEvidence, Consensus, Elicit, and Examine.
21. Scientific evidence for knowledge graphs, longitudinal phenotyping, and patient-generated health data.
22. Safety design for hypothesis generation, uncertainty communication, red-flag escalation, and human oversight.
23. United States FDA boundary analysis for wellness, clinical decision support, and software as a medical device.
24. United States HIPAA, FTC Health Breach Notification Rule, state consumer-health-data laws, and liability exposure.
25. European Union GDPR, MDR, AI Act, and health-app implications.
26. United Kingdom and Australian health-data, medical-device, and consumer-protection implications.
27. Privacy architecture, end-to-end encryption, key management, search on encrypted data, deletion, portability, and auditability.
28. Interoperability architecture: FHIR, SMART on FHIR, Apple Health/HealthKit, laboratory imports, OCR, and provenance.
29. Safe AI/RAG architecture for medical literature retrieval, citation verification, calibration, and hallucination controls.
30. Health knowledge-graph and pathway-model architecture, including ontology and provenance options.
31. Market-size proxies, category growth, and defensible bottom-up TAM/SAM/SOM methods.
32. Business models, pricing, unit-economics constraints, and practitioner versus consumer monetization.
33. Go-to-market routes through condition communities, clinicians, creators, employers, research partners, and advocacy groups.
34. Condition-wedge comparison across eczema, digestive disorders, fatigue/Long COVID, migraine, autoimmune conditions, and women’s health.
35. Clinical validation, quality-management, post-market monitoring, and evidence-generation roadmap.
36. Failure cases, litigation/reputational patterns, and lessons from discontinued or controversial digital-health products.

## Evidence standard

Each workstream must distinguish verified current product facts from interpretations; prioritize official product pages, app-store listings, regulatory guidance, statutes, peer-reviewed research, and credible user-review sources; provide direct URLs and dates; identify contradictions or uncertainty; and translate evidence into product implications without making clinical claims. The final synthesis will explicitly separate **confirmed gaps**, **likely gaps**, and **unvalidated opportunities**.
