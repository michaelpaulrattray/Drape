# Personal Health “Second Brain” SaaS

## Comprehensive Market, Competitor, Gap, Product, and Validation Research

**Prepared by:** Manus AI  
**Research date:** 31 July 2026  
**Purpose:** Evidence pack for Claude Fable to produce the final operating plan  
**Status:** Strategic research, not medical, legal, regulatory, or investment advice

---

## Executive summary

The proposed product addresses a serious and persistent problem: people with chronic or unexplained symptoms must reconstruct a longitudinal health story from portals, PDFs, labs, wearables, medication histories, memories, and daily observations. The need population is large. A 2025 CDC analysis estimated that **76.4% of U.S. adults—about 194 million people—reported at least one of 12 selected chronic conditions in 2023, while 51.4%—roughly 130–131 million—reported two or more**.[23] These figures establish need, but they are not a revenue market. Only a fraction of these adults will be digitally engaged, willing to consolidate sensitive data, able to sustain tracking, and willing or able to pay.

The original concept is nevertheless **too broad and insufficiently differentiated for a full build**. Guava already combines clinical-record aggregation, device connections, symptom and medication tracking, correlations, AI assistance, uploaded-document extraction, and appointment preparation.[1] [2] Bearable offers customizable tracking, correlations, reports, goals, and self-experimentation.[3] Human Health uses a “personal health lab” narrative and markets AI-assisted pattern recognition.[5] CareClinic combines detailed tracking, record storage, assessments, guided pathways, and provider sharing.[6] Visible shows that a narrow condition wedge plus passive monitoring and a legible job—pacing—is more defensible than a generic tracker.[7] Heads Up Health already provides multi-source health-data aggregation and AI-oriented clinical intelligence to practitioners.[8]

The market gap is therefore **not** “all my health data in one place,” “AI discovers patterns,” “a root-cause explorer,” “evidence-based pathways,” or “a report for my doctor.” These claims are occupied. The strongest plausible gap is narrower:

> **A provenance-first, safety-conservative personal health evidence navigator that turns fragmented longitudinal data into a trustworthy health timeline, inspectable associations, competing evidence-linked hypotheses, and a concise clinician-reviewable packet—without diagnosing, ranking root causes, or recommending treatment.**

The recommended initial wedge is **complex-care visit preparation for adults with post-viral illness, dysautonomia/POTS, exertion intolerance or fatigue, and overlapping multi-system symptoms**. The product should solve one job: help a person convert months of fragmented information into an accurate, source-linked story and a focused set of questions for a clinician. “Second brain” can remain an internal metaphor, but the public category should be a **personal health evidence and visit-preparation workspace**. The phrase “root cause” should be removed from launch positioning because it is crowded, clinically misleading, and likely to pull product behavior toward diagnosis or treatment selection.

The recommended sequence is not a software roadmap. It is a staged validation program. Start with a **concierge evidence-and-visit service**, test the artifact with patients and clinicians, then automate only the repeated and validated workflow. A D2C self-service product should follow only if the concierge pilot proves accuracy, usefulness, acceptable burden, willingness to pay, and clinician acceptance. A clinic-sponsored channel should follow only after a budget owner and measurable workflow benefit are demonstrated.

| Decision | Recommendation |
|---|---|
| Proceed with the broad “root-cause second brain” vision | **No.** It is crowded, medically risky, technically over-scoped, and not yet supported by primary customer evidence. |
| Proceed with a narrow validation program | **Yes.** Validate longitudinal story reconstruction and visit preparation before substantial product development. |
| Initial user | Adults with complex, persistent multi-system symptoms who already use several portals, documents, trackers, or wearables. |
| Initial job | Prepare a reliable, evidence-linked story and concise question set for a real clinical visit. |
| Initial output | One- to two-page clinician packet plus an inspectable evidence and provenance appendix. |
| Safety boundary | No diagnosis, ranked “root causes,” treatment plans, medication/supplement changes, emergency reassurance, or autonomous test interpretation. |
| Initial business-model test | One-time paid appointment packet plus a low-cost recurring evidence workspace; supplement with clinic, advocacy, or research-cohort sponsorship. |
| Core moat | Data lineage, clinician-validated reporting, contradiction-aware evidence retrieval, a versioned safety/evaluation system, and trusted distribution—not the language model itself. |

---

## 1. Research method and evidence standard

This investigation used **36 parallel workstreams**, covering user needs, 16 direct and adjacent competitor categories, evidence-search products, scientific validity, safety, U.S./EU/UK/Australian regulation, privacy architecture, interoperability, medical AI, knowledge graphs, market sizing, monetization, go-to-market, condition wedges, clinical validation, and digital-health failure cases. The workstreams generated **219 parsed citations across 192 unique URLs**. Twenty-three workstreams were rated high evidence quality and thirteen medium. High-stakes findings were then checked against current official product pages, FDA, FTC, HHS, CDC, CMS, standards documentation, and peer-reviewed methods literature.

The source hierarchy was: current official product and pricing pages for competitor capabilities; statutes, agency guidance, and standards documentation for legal and technical boundaries; peer-reviewed research for scientific claims; and independent reviews or community discussions only for qualitative friction signals. Market-report headlines were treated as weak proxies and were not used as the primary market-sizing method.

The central limitation is material: this is **public-source research**, not product testing, legal analysis, user research, or access to proprietary retention and revenue data. A capability described as “not publicly verified” must not be represented as “absent.” Competitors can add features quickly, and public pages often simplify functionality. The final plan must include hands-on product testing and customer interviews before treating a gap as defensible.

| Evidence label | Meaning | Permitted planning use |
|---|---|---|
| Confirmed | Present on a current official page, authoritative document, or strong primary source. | May be treated as a planning fact, subject to date and jurisdiction. |
| Corroborated | Supported by more than one credible source, but not necessarily independently audited. | May guide strategy, with the evidence caveat retained. |
| Likely | Inferred from product materials or recurring qualitative feedback. | May become a testable hypothesis, not a roadmap assumption. |
| Not publicly verified | No evidence found in the reviewed public materials. | May be investigated as whitespace; it must not be called a confirmed absence. |
| Assumption | A proposed threshold, segment choice, price, or causal belief. | Must be tested before investment or launch. |

---

## 2. Problem definition and user jobs

The core problem is not a lack of health data. It is the inability to turn heterogeneous, incomplete, and sometimes conflicting observations into a useful longitudinal account. Clinical systems organize encounters; wearables organize device-specific measurements; symptom trackers organize daily entries; patient portals organize one institution; and research tools organize literature. The user must perform the synthesis.

Research on chronic-illness self-tracking shows that rigid predefined fields can reduce agency, while flexible systems can better reflect idiosyncratic symptoms and goals. The same flexibility can also create setup burden, excessive logging, and “pointless pressure.”[38] Community discussions around Bearable and Guava, plus a very small Guava review sample, are anecdotal rather than population evidence, but they repeatedly illustrate the trade-off: detail is valuable until the effort required to maintain it overwhelms the user.[39] [40] [41]

The most important jobs are therefore practical rather than diagnostic:

| Job to be done | Current workaround | Failure of the workaround | Product implication |
|---|---|---|---|
| Reconstruct “what happened when” | Portals, calendar, notes, memory, spreadsheets | Dates conflict; changes and delayed effects are hard to see | Build a source-linked longitudinal spine before advanced AI. |
| Consolidate records across organizations | Portal downloads, folders, email, manual requests | Formats vary; coverage and freshness are unclear | Show source coverage, missingness, and verification state. |
| Track symptoms without spending the day tracking | Paper, phone notes, symptom apps | Manual burden causes missing data and abandonment | Use passive import, sparse adaptive check-ins, and user-defined priorities. |
| Understand possible patterns | Charts, spreadsheets, tracker correlations | Same-day correlations and multiple comparisons invite false conclusions | Show lag choices, sample size, missingness, uncertainty, and non-causal wording. |
| Research what might be relevant | Search engines, social media, PubMed, AI chat | Evidence quality, applicability, and contradiction are difficult to judge | Retrieve cited evidence with study type, applicability, date, and contrary findings. |
| Prepare for a short clinical appointment | Long notes, binders, screenshots, verbal summaries | The most decision-relevant facts are buried | Produce a one-page summary with an inspectable appendix. |
| Preserve ownership and control | DIY tools or avoidance | Consumer health apps may sit outside HIPAA and use opaque third parties | Make consent, purpose, access, export, and deletion visible product functions. |

The product must deliver value before requiring weeks of perfect data. The first “aha” should be an accurate imported timeline or a better appointment packet, not a speculative correlation.

---

## 3. Market context and sizing discipline

The CDC’s 130–131 million U.S. adults with multiple selected chronic conditions form a relevant need denominator, but several filters stand between prevalence and revenue: symptom complexity, digital access, willingness to aggregate data, perceived privacy risk, capacity for ongoing use, acquisition-channel reach, and payer availability.[23] Chronic-disease burden is also higher in communities that may face lower incomes, insurance barriers, transportation constraints, and poorer access to care.[24] [25] A premium, manual-input-heavy product could therefore select for affluent quantified-self users rather than the people most burdened by fragmented care.

A defensible model should be built from observable channels rather than commercial market-report estimates:

> **Qualified people reached × activation rate × report completion × paid conversion × annual revenue per paying user = obtainable annual revenue.**

Each input should be labeled **measured**, **externally benchmarked**, or **assumed**. The final plan should model community partnerships, clinic cohorts, creator audiences, and paid acquisition separately because their conversion, support burden, and trust dynamics will differ. Until primary research produces these inputs, TAM, SAM, and SOM should be formulas and scenarios rather than a single headline number.

| Market layer | Definition | What is currently known | What must be measured |
|---|---|---|---|
| Need population | Adults with multiple conditions or persistent, unexplained, multi-system symptoms | The CDC estimates roughly 130–131 million U.S. adults have two or more selected chronic conditions.[23] | Share with the specific target job, data fragmentation, and sufficient digital access. |
| Reachable early adopters | People already using trackers, portals, wearables, condition communities, or appointment-preparation workarounds | Public communities and competitor adoption show an active segment, but not its reachable size. | Audience overlap, qualified traffic, trust, activation, and channel cost. |
| Paying serviceable market | Users or sponsors with a budget and repeated value | Low-cost competitor subscriptions establish a difficult D2C benchmark.[2] [4] | Paid conversion, price sensitivity, retention, support cost, and sponsor economics. |
| Obtainable market | Cohorts reachable through specific communities, clinics, research programs, or paid channels | Unknown before pilots. | Partner capacity, sales cycle, onboarding throughput, and cohort retention. |

---

## 4. Market landscape

![Market gap map](market_gap_map.png)

The market consists of overlapping categories rather than a single direct-competitor set. A user can substitute a symptom tracker, a record aggregator, a practitioner platform, a symptom checker, a literature search tool, or a DIY system depending on the immediate job.

| Category | Representative products | Primary strength | Structural limitation for the proposed job |
|---|---|---|---|
| Personal record aggregation | Guava, PicnicHealth, OneRecord, Apple Health Records | Consolidates records and supports sharing | Aggregation alone does not establish evidence quality, causality, or clinician usefulness. |
| Symptom, habit, and medication tracking | Bearable, Human Health, CareClinic, Flaredown, mySymptoms | Flexible day-to-day capture and correlations | Manual burden, fragmented clinical data, and weak provenance can limit long-term value. |
| Condition-specific monitoring | Visible | Narrow job, passive sensing, legible action model | The model and data sources are condition-specific rather than a general longitudinal record. |
| Practitioner clinical intelligence | Heads Up Health, Practice Better, Fullscript, Rupa | Multi-source data and clinician workflow | Practitioner-led, often expensive, and not designed around patient-controlled cross-provider synthesis. |
| Biomarker personalization | Function Health, InsideTracker, Ornament | Testing, lab interpretation, and optimization | Focuses on periodic biomarker snapshots rather than the complete lived timeline. |
| Communities and research networks | PatientsLikeMe, StuffThatWorks, Open Humans | Peer experience, cohorts, and research participation | Crowdsourced observations do not automatically become individual clinical evidence. |
| Point-in-time symptom assessment | Ada, K Health, Buoy, Healthily | Structured intake, triage, and episodic assessment | Weak longitudinal context and higher diagnostic/regulatory exposure. |
| Medical evidence search | OpenEvidence, Consensus, Elicit, Examine | Cited answers and literature synthesis | Disconnected from personal data, consent, provenance, and the clinical visit workflow. |
| DIY knowledge systems | Notion, Obsidian, spreadsheets, paper | Flexibility, control, and low switching cost | High setup and maintenance effort; no native health-data ingestion or safety model. |

---

## 5. Competitor deep dive

### 5.1 Direct and near-direct competitors

| Product | Confirmed current proposition | Pricing signal | What it already invalidates | Plausible or unverified gap |
|---|---|---|---|---|
| **Guava Health** | Portal and device sync, symptom/medication/lifestyle tracking, correlations, document and imaging upload, record search, lab extraction, AI assistance, and doctor-visit preparation.[1] [2] | Free; Premium displayed at **US$8/month or US$78/year** as of the research date.[2] | “One place for all my health,” correlations, AI record Q&A, uploaded-lab extraction, and appointment preparation are not whitespace. | Sentence-level evidence provenance, contradiction-aware literature retrieval, governed N-of-1 methods, and an explicit observation-to-hypothesis evidence ladder were not verified in reviewed public materials. |
| **Bearable** | Highly customizable symptom, mood, habit, treatment, and lifestyle logging; reports, correlations, experiments, goals, reminders, and health-platform integration.[3] | Official page displays **US$6.99/month or US$34.99/year**, with a free tier and periodic discounts.[4] | Custom tracking, correlations, experiments, and affordable freemium positioning are occupied. | Deep clinical-record aggregation, a clinician collaboration workflow, and cited evidence linked to personal hypotheses were not verified. |
| **Human Health** | Symptom and treatment tracking, health history, pattern assistance, provider communication, wearable/vital inputs, reports, and research participation.[5] | Free entry with paid HumanPlus features; current regional pricing should be verified in-app before publication. | “Personal health lab,” chronic-condition pattern discovery, and provider communication are occupied narratives. | Comprehensive multi-EHR ingestion, transparent literature provenance, and a rigorous causal-inference layer were not verified. |
| **CareClinic** | Symptoms, medications, vitals, lifestyle, records, devices, caregiver/provider sharing, validated assessments, and guided care pathways.[6] | Freemium/premium; exact current store price varies and should be checked by geography. | “Evidence-based care plans,” guided pathways, records, assessments, and provider reports are occupied. | A conservative contradiction-aware hypothesis workspace and transparent data lineage were not verified. |
| **Visible** | Pacing for Long COVID, ME/CFS, POTS, fibromyalgia and other energy-limiting conditions; continuous heart-rate band, alerts, energy budgeting, HRV trends, logging, reports, and education.[7] | Subscription/hardware model; exact local pricing should be verified at checkout. | A narrow chronic-illness wedge, passive monitoring, pacing, and clinician reports are occupied. | Cross-provider record aggregation, hardware-agnostic multi-system evidence synthesis, and broader longitudinal provenance are not its public focus. |
| **PicnicHealth** | Record retrieval and organization, automatic updates, a smart health assistant, optional connected-care visit, and sponsored research participation.[9] | **US$499/year**; free during eligible research participation; **US$149** connected-care visit, potentially lower with insurance.[9] | High-touch record collection, research-sponsored access, and record-informed clinical review are occupied. | Continuous symptom/wearable experimentation and a consumer-controlled evidence graph are not the primary public proposition. |
| **Heads Up Health** | Practitioner-oriented aggregation of labs, wearables, EHRs, symptoms, nutrition and diagnostics, with AI, alerts, reports, APIs and branded deployments.[8] | Custom organizational pricing.[10] | Practitioner dashboards, multi-source aggregation, AI clinical intelligence, and configurable reporting are occupied. | An affordable consumer-owned workspace with strict non-diagnostic evidence navigation is not the public center of gravity. |

### 5.2 Adjacent and substitute competitors

| Product or group | User reason to choose it | Threat to the concept | Remaining opportunity |
|---|---|---|---|
| OneRecord, Apple Health Records, patient portals | Free access to clinical records and standards-based data | The aggregation layer can become a commodity or platform feature.[11] [30] | Reconciliation, provenance, longitudinal interpretation, and visit workflow remain unsolved across sources. |
| Seqster and enterprise longitudinal-data platforms | Robust normalization and life-sciences/health-system connectivity | Enterprise vendors can move down-market or power partners.[12] | Consumer experience, patient-controlled hypotheses, and transparent evidence may remain outside their core model. |
| Function Health and InsideTracker | Testing plus understandable biomarker interpretation | Users may prefer a concrete lab service over a software-only subscription. | Integrate existing records rather than selling more tests; focus on context, change over time, and clinician review. |
| Ornament and Carrot Care | Fast lab capture and explanation | Lab OCR and interpretation are already familiar features. | Make lab data traceable, verified, and integrated with symptoms, medication changes, and source documents. |
| PatientsLikeMe, StuffThatWorks, Open Humans | Community knowledge, peer experience, and research participation | Communities already own trust and condition-specific traffic.[13] [14] | Partner rather than compete; separate personal evidence from crowd anecdotes and obtain explicit research consent. |
| Ada, K Health, Buoy, Healthily | Immediate answers and triage | They set user expectations for conversational health AI.[15] | Avoid episodic diagnosis; win on longitudinal context, citations, and preparation. |
| OpenEvidence, Consensus, Elicit, Examine | Fast literature answers with citations | Evidence retrieval is not a standalone moat. | Bind evidence to verified personal facts, applicability, contradictions, and an auditable visit artifact. |
| Notion, Obsidian, spreadsheets | Maximum flexibility, control, and exportability | Highly motivated users can create adequate systems at low cost. | Automate imports, provenance, normalization, and safety while preserving flexibility and export. |

---

## 6. What competitors are not visibly doing—and what is actually defensible

Competitor whitespace must be stated precisely. The following are the strongest opportunities found, but most remain **unverified gaps** until product testing and win/loss interviews demonstrate that current products do not already solve them adequately.

| Gap hypothesis | Why it matters | Public coverage found | Defensibility | Required proof |
|---|---|---:|---:|---|
| Sentence-level provenance for personalized outputs | A user or clinician can inspect the exact source, date, study type, applicability, and contradicting evidence behind a statement. | Low or not publicly verified | High if coupled with evaluation and workflow | Benchmark citation entailment; clinician trust and use study. |
| Explicit evidence ladder | Separates observation, association, hypothesis, experiment candidate, and result to reduce causal overreach. | Low or not publicly verified | Medium–high through UX, methods, and policy | Comprehension testing and evidence that warnings prevent false confidence. |
| Lag-, trend-, and missingness-aware analysis | Chronic symptoms may follow delayed or cumulative exposures, while sparse self-tracking produces biased correlations. | Partial; rigor not publicly verifiable | Medium | Statistical benchmark, sensitivity analysis, and expert review. |
| Data lineage and reconciliation | Conflicting wearables, OCR errors, duplicate records, unit changes, and stale connections corrupt downstream conclusions. | Rarely exposed to users | High | Critical-field extraction accuracy, correction burden, and provenance comprehension. |
| Contradiction-aware evidence retrieval | A system that returns only confirming studies can reinforce health anxiety and self-diagnosis. | Not publicly verified in direct competitors | High if reliably evaluated | Curated benchmark against guidelines, systematic reviews, and adversarial queries. |
| Dual-audience report | Patients need agency; clinicians need a concise, non-diagnostic artifact that fits a short visit. | Reports exist, but clinician acceptance is not proven | High through workflow learning | Blinded clinician scoring and observed real-visit use. |
| Governed low-risk N-of-1 protocols | Users already self-experiment without washout, stop rules, or confounder handling. | “Experiments” exist; methodological rigor is unclear | Medium–high | Safety scope, ethics review, and prospective pilot. |
| Transparent privacy architecture | “We do not sell data” does not address SDK leakage, access controls, secondary use, or breach response. | Privacy claims are common; architecture is opaque | High but expensive | Independent threat model, vendor audit, deletion test, and trust research. |

The key strategic conclusion is that the product cannot differentiate through **feature quantity**. Guava and CareClinic already have broad surfaces. It must differentiate through **epistemic quality**: how facts are sourced, how uncertainty is displayed, how unsafe inference is blocked, and whether the final artifact improves a real clinical interaction.

---

## 7. Recommended segment and positioning

The recommended beachhead is a **job-based wedge inside a condition cluster**. The job is complex-care visit preparation; the initial cohort is adults with post-viral illness, dysautonomia/POTS, exertion intolerance or fatigue, and overlapping multi-system symptoms. Visible proves that this community values passive monitoring and condition-specific language, while Guava and Bearable demonstrate demand for broader record and symptom organization.[1] [3] [7]

This cohort is strategically attractive because it often has multiple clinicians, fluctuating symptoms, delayed exertional effects, wearable data, and active patient communities. It is also difficult: many users have low energy, cognitive impairment, uncertain diagnoses, and limited ability to pay. The product must therefore earn trust quickly, minimize manual work, and avoid suggesting that more tracking will necessarily reveal a single cause.

| Positioning element | Recommendation |
|---|---|
| Public category | **Personal health evidence and visit-preparation workspace** |
| Primary promise | “Turn fragmented health data into a reliable story and focused questions for your clinician.” |
| Working message | **“Bring your health story into focus—without turning correlations into conclusions.”** |
| Primary user | A person with persistent multi-system symptoms and fragmented records across several sources. |
| Trigger | Upcoming specialist visit, new clinician, flare, medication change, disability documentation, or the need to reconstruct history. |
| Hero output | A one- to two-page visit packet plus an inspectable evidence appendix. |
| Emotional benefit | Agency and clarity without alarmism or false certainty. |
| Terms to avoid | Root cause, diagnosis, cure, reverse, prevent, optimize every biomarker, personalized treatment, doctor replacement. |

| Candidate wedge | Need intensity | Crowding | Passive-data fit | Community access | Safety complexity | Assessment |
|---|---:|---:|---:|---:|---:|---|
| Post-viral illness, POTS, ME/CFS, fatigue | Very high | Medium | High | High | High | **Recommended test cohort**, with strict burden and safety controls. |
| Migraine | High | High | High | High | Medium–high | Easier outcomes but more dedicated trackers; potential second cohort. |
| Digestive symptoms/IBS | High | High | Medium | High | High | Attractive later; restrictive-diet and food-causality risks are material. |
| Eczema | Medium–high | Medium | Medium | Medium | Medium–high | Visual tracking helps, but cross-record synthesis may be less urgent. |
| Broad autoimmune or women’s health | Very high | High and fragmented | Medium–high | High | Very high | Too broad and sensitive for the first cohort. |
| Quantified self/longevity | Medium | Very high | Very high | Medium | Medium | Higher willingness to pay but crowded and misaligned with the stated mission. |

---

## 8. Product recommendation and MVP boundary

The MVP should prove that a person can create a **more trustworthy and useful clinical story with less effort**, and that a clinician can review it quickly. It should not attempt to build a complete health operating system.

### 8.1 Include in the first self-service product

| Capability | Minimum behavior | Why it belongs |
|---|---|---|
| Longitudinal timeline | Symptoms, medications, diagnoses, procedures, tests, user-defined events, and contextual notes | Creates the common spine for every later feature. |
| Passive data import | Apple HealthKit and Android Health Connect, with source and permission visibility | Reduces logging burden and supports baselines.[31] [32] |
| Clinical-data import | User-authorized FHIR connections where available; structured CSV/JSON; then documents | Begins with the most reliable routes and acknowledges coverage limits.[29] [30] |
| Document extraction | PDF/image import with provisional values and mandatory human verification | Solves fragmentation without presenting OCR as ground truth. |
| Provenance and reconciliation | Original value/unit, normalized value, source, timestamp, parser version, confidence, verification status, duplicates, and corrections | Makes downstream outputs auditable and correctable. |
| Sparse adaptive check-ins | Small user-defined symptom set, low-frequency baseline, prompts only when analytically useful | Respects fatigue, disability, and fluctuating capacity. |
| Descriptive analytics | Trends and lag-aware associations with sample size, missingness, effect estimate, and uncertainty | Creates insight without converting association into diagnosis. |
| Evidence cards | Peer-reviewed or authoritative sources with study type, date, population, applicability, and limitations | Makes AI output inspectable and useful for questions. |
| Competing-hypothesis workspace | Multiple user-visible hypotheses, supporting and contradicting evidence, no diagnostic rank | Organizes uncertainty rather than pretending to resolve it. |
| Clinician packet | One-page summary, medication/treatment changes, verified timeline, key trends, user goals, and questions; appendix with provenance | Produces a concrete outcome that can be validated. |
| Trust controls | Export, deletion, consent scopes, access log, research opt-in, and no advertising SDKs | Privacy is part of the product, not only a policy. |

### 8.2 Explicitly exclude from MVP

| Excluded function | Rationale |
|---|---|
| Diagnosis, disease probabilities, or ranked root causes | Noisy personal data cannot support this safely; the function can become regulated and create direct harm. |
| Medication, supplement, test, fasting, elimination-diet, or treatment recommendations | These outputs can change care and cross the intended regulatory boundary. |
| Emergency or time-critical triage | A longitudinal workspace must not create false reassurance in urgent situations. |
| Automated test ordering or standalone lab interpretation | Adds clinical responsibility, licensing, liability, and regulated-function risk. |
| Nationwide “complete” record connectivity | Provider and payer connectivity, formats, and document availability remain uneven. |
| Genetics, microbiome, and broad biomarker optimization | Adds cost, interpretive ambiguity, and marketing risk before the core workflow is proven. |
| Open peer diagnosis matching | Encourages misinformation, privacy leakage, and reinforcement of unverified beliefs. |
| Employer access to individual-level health analytics | Creates surveillance, discrimination, and trust risks. |
| Advertising or identifiable/de-identified health-data monetization | Conflicts with the core trust position and creates re-identification, consent, and enforcement exposure. |

### 8.3 Product design principles

The product should be **mobile-first for capture and passive health-platform access**, with a web companion for record review, evidence reading, and report preparation. The default interaction should be calm and sparse. It should avoid streaks, guilt, excessive alerts, and endless dashboards. A “pause tracking” mode, caregiver assistance, adjustable reminder frequency, accessibility support, and plain-language uncertainty explanations are requirements for the chosen cohort rather than optional polish.

The interface should reveal data quality at the point of interpretation. A graph should never appear without its source, date range, missingness, and interpretation boundary. A user should be able to trace every statement in the clinician packet back to a verified datum or cited source.

---

## 9. Scientific validity and the evidence ladder

Self-tracked longitudinal data can generate useful **candidate hypotheses**, but observational associations are not automatically causal. Valid within-person inference must account for autocorrelation, underlying trends, delayed onset or decay, carryover, time-varying confounders, and missingness.[26] [27] [37] Consumer wearables also require analytical and clinical validation for the specific context of use; continuous and precise-looking readings are not equivalent to validated clinical endpoints.[28]

The application should therefore implement an explicit ladder:

| Level | Permitted statement | Required evidence and guardrail |
|---|---|---|
| 1. Observation | “Fatigue entries and resting heart rate were higher during this period.” | Source and device shown; data quality, missingness, and verification visible. |
| 2. Association | “Higher activity days were followed by higher fatigue entries 24–48 hours later in this dataset.” | Predefined or disclosed lag, sample size, effect estimate, uncertainty, multiple-testing warning, no causal language. |
| 3. Hypothesis | “Several explanations could be relevant to discuss; evidence is mixed.” | Multiple alternatives, supporting and contradicting evidence, applicability limits, no diagnostic rank. |
| 4. Low-risk experiment candidate | “A consistent bedtime could be tested as a reversible behavior.” | Contraindication screen, low-risk scope, defined outcome, duration, and stop rules. |
| 5. Clinician-reviewed N-of-1 protocol | A pre-specified comparison under professional review | Baseline, randomization where feasible, washout/carryover assumptions, adverse-event capture, analysis plan. |
| 6. Result | “This individual pattern was observed under these conditions.” | Sensitivity analysis, context retained, no automatic generalization to another person or condition. |

The product should refuse experiments involving medication changes, supplement escalation, dangerous restriction, pregnancy-related decisions, severe symptoms, or other high-risk contexts without appropriate professional oversight. It should label exploratory analyses, disclose how many relationships were tested, and show whether the result changes under reasonable lag or missing-data choices. “X caused Y” should be prohibited unless the system is displaying a properly designed and reviewed experiment whose assumptions and limitations remain visible.

---

## 10. Medical safety and AI policy

The safety model must constrain **function**, not merely add a disclaimer. A disclaimer cannot neutralize a feature that ranks diagnoses, interprets patient-specific signals, or recommends treatment. The safer role is an evidence navigator and question generator.

| Output class | Allow | Restrict or block |
|---|---|---|
| Personal-data summary | Summarize verified facts, dates, trends, missingness, and user-stated goals. | Do not infer a diagnosis or omit uncertainty. |
| Literature retrieval | Quote or summarize relevant evidence with citations, study type, date, population, and limitations. | Do not fabricate citations, cherry-pick confirming evidence, or imply universal applicability. |
| Hypothesis organization | Display multiple possibilities the user or clinician has entered or that the evidence makes relevant to discuss. | Do not rank a disease probability or state that a condition explains the user’s data. |
| Association analysis | Describe non-causal within-person relationships with statistical context. | Do not use causal verbs, hide multiple testing, or suppress contradictory windows. |
| Visit preparation | Generate questions, factual corrections, and a concise history. | Do not provide a treatment plan or replace professional evaluation. |
| Red flags | Provide simple, deterministic directions to emergency or professional services when configured criteria are met. | Do not perform autonomous probabilistic triage or imply that no alert means safety. |
| Experiment support | Support low-risk, reversible behavior protocols after screening. | Block medication, supplement, test-ordering, dangerous restriction, and time-critical decisions. |

A production release should require a versioned evaluation suite covering factual extraction, citation entailment, contradiction handling, diagnostic leakage, treatment leakage, emergency reassurance, bias, privacy leakage, prompt injection, and adversarial manipulation. Retrieval-augmented generation can reduce unsupported output, but current reviews show that it is not a complete safety solution and can perform poorly when retrieved sources conflict.[33] [34] High-severity failures should be **hard-blocked**, not softened with a warning.

The product should also monitor potential psychological harm. Excessive checking, symptom fixation, false precision, and anxiety amplification are plausible adverse effects. Notification limits, calm defaults, pause mode, and a user-facing explanation of when tracking is not helpful should be included in safety evaluation.

---

## 11. Regulatory and legal boundary

### 11.1 United States

The FDA’s January 2026 Clinical Decision Support Software guidance clarifies the statutory criteria for non-device CDS and emphasizes independent review of the basis for recommendations. FDA materials also state that simple software allowing patients to organize, record, display, or communicate health information is not a medical device; function-specific, risk-based policies continue to apply.[16] [17] The January 2026 General Wellness guidance covers low-risk software intended to maintain or encourage a healthy lifestyle **unrelated to diagnosis, cure, mitigation, prevention, or treatment of disease**.[18] That framing is a poor fit for a product marketed around chronic-disease “root causes.”

A consumer-facing feature that ranks causes, interprets patient-specific laboratory or wearable signals, recommends testing, or suggests treatment changes can move toward device functionality. The launch version should instead summarize user-entered facts, present non-causal associations with data quality, retrieve literature, show multiple non-ranked hypotheses, explain applicability, block time-critical use, and generate clinician questions. Formal counsel should conduct a function-by-function review; if personalized pathway ranking is contemplated later, early FDA engagement may be appropriate.

HIPAA is not the only—or necessarily the main—privacy regime. HHS explains that a direct-to-consumer app can hold data originating from a hospital without becoming a HIPAA covered entity merely for that reason.[21] A joint FTC/HHS/FDA tool further illustrates that several federal regimes can apply to the same health application.[22] The FTC’s Health Breach Notification Rule applies to many consumer health apps, and the 2024 amendments clarified coverage of health apps and connected devices. Unauthorized disclosure can constitute a breach even without a traditional hack.[19] The proposed product, which would combine user inputs, wearables, records, and external sources, closely resembles the FTC’s definition of a vendor of personal health records.

The FTC Act also prohibits deceptive privacy, security, performance, safety, and health claims. Health-benefit claims require appropriate substantiation.[20] Therefore, “HIPAA compliant,” “end-to-end encrypted,” “finds root causes,” “clinically proven,” and “never shares your data” must not be used without a precise role, architecture, and evidence basis. State consumer-health-data laws require separate review, especially where consent, deletion, geofencing, and private enforcement differ.

### 11.2 European Union, United Kingdom, and Australia

Health data are specially protected in these jurisdictions. EU expansion introduces GDPR special-category processing, the Medical Device Regulation, and the AI Act; software with diagnostic, monitoring, or treatment purposes can enter medical-device and high-risk AI regimes. In the United Kingdom, the ICO treats health information as special-category data and the MHRA regulates software according to intended medical purpose.[42] [43] Australia’s OAIC treats health information as sensitive information, while the TGA regulates software-based medical devices and publishes exclusions that depend on function and claims.[44] [45]

The practical recommendation is to **launch in one jurisdiction**, complete a formal product-and-marketing review, and delay global availability until consent, data-subject rights, breach processes, clinical claims, hosting, age controls, and medical-device analysis are localized. “Available worldwide” should not be an early success metric.

### 11.3 Regulatory decision table

| Proposed function | Lower-risk formulation | Higher-risk formulation to avoid initially |
|---|---|---|
| Timeline | “Here are the verified events you imported or entered.” | “This timeline reveals the onset of disease X.” |
| Association | “These variables moved together in your dataset; the relationship may be coincidental.” | “Food Y triggered your condition.” |
| Evidence | “These studies discuss mechanisms that may be relevant to ask about.” | “The literature confirms your root cause.” |
| Hypotheses | “Here are non-ranked questions for a clinician, with supporting and contradictory evidence.” | “You most likely have X; request test Z.” |
| Labs | “This is the value, range, source, and date; verify the extraction.” | “This abnormality means you need supplement Q.” |
| Red flags | “If you are experiencing this severe symptom, seek urgent professional help.” | “You are safe to remain at home.” |

---

## 12. Privacy, security, and trust architecture

A credible privacy promise must describe the actual data flow. “End-to-end encrypted AI” is internally inconsistent if a cloud model must receive plaintext. True end-to-end encryption would require on-device inference, a carefully designed trusted-compute approach, or explicit client-side decryption for a defined operation. The MVP should not claim zero-knowledge processing unless the architecture proves it.

The defensible initial promise is narrower: encryption in transit and at rest; field-level protection for especially sensitive values; strict tenant isolation; least-privilege access; short-lived credentials; audited administrative access; no advertising SDKs; no sale of data; explicit, purpose-bound secondary-use consent; and tested export and deletion. Health events should be isolated from generic product analytics. Logs, support tools, crash reporters, experimentation systems, and AI vendors must all be included in the data-flow inventory.

| Control domain | Minimum requirement |
|---|---|
| Collection | Data minimization; every field has a documented purpose and retention rule. |
| Consent | Separate, revocable scopes for core service, clinician sharing, research, and product improvement. |
| Identity | Strong authentication, optional passkeys/MFA, secure account recovery, and device/session visibility. |
| Authorization | Least privilege, tenant isolation, role-based access, time-limited support access, and explicit caregiver delegation. |
| Encryption | Modern transport encryption, strong at-rest encryption, managed key rotation, and field-level protection where appropriate. |
| Data lineage | Immutable provenance and correction history without preventing lawful deletion of user content. |
| AI processing | Contractual no-training/no-secondary-use terms, minimal prompts, redaction where feasible, and provider isolation. |
| Analytics | No ad-tech SDKs; health-event analytics segregated, minimized, and consented where required. |
| Sharing | User-visible recipient, purpose, scope, expiration, and revocation. |
| User rights | Export in usable formats, deletion workflow, consent withdrawal, and access log. |
| Incident response | FTC/HIPAA/state-specific decision tree, notification workflow, forensic readiness, and tabletop tests. |
| Vendors | Security and privacy review, data-processing terms, subprocessor inventory, and breach obligations. |

An independent threat model, privacy impact assessment, external penetration test, deletion test, and incident-response exercise should precede a public launch. Trust should be verified through user research: privacy architecture is strategically valuable only if users understand it and it affects adoption or retention.

---

## 13. Interoperability and data architecture

SMART App Launch uses OAuth-based authorization, scoped permissions, capability discovery, and FHIR resources for patient and provider applications.[29] CMS Patient Access APIs can expose maintained claims, encounter, and clinical data, including laboratory data, but they do not guarantee that every PDF, fax, or historical document is transformed into discrete FHIR elements.[30] Apple HealthKit and Android Health Connect provide permissioned access to device-centric health and fitness records; Health Connect’s medical-record functionality uses FHIR.[31] [32] Google’s legacy Fit APIs are scheduled to remain supported only through the end of 2026, creating a migration consideration for products that rely on them.[32]

HHS analysis of patient-generated health data likewise identifies interoperability, workflow integration, data quality, and governance as core infrastructure challenges.[36] “Connect all my records” therefore requires a multi-route ingestion strategy:

1. HealthKit and Health Connect for device and app data.
2. User-authorized FHIR connections for compatible payer and provider records.
3. Structured CSV/JSON or supported vendor exports.
4. PDF and image ingestion with OCR and mandatory verification.
5. Manual entry for unresolved gaps.

Every datum should preserve **source, original value, original unit, normalized value, timestamp, institution or device, parser/version, consent scope, confidence, verification status, and correction history**. Imported records must expose connection coverage, freshness, unsupported resource types, and missingness. An OCR-extracted lab value should remain visibly provisional until the user confirms the test name, specimen date, value, unit, reference range, and source document.

### 13.1 Reference architecture

| Layer | Recommended design | Main risk |
|---|---|---|
| Client | Native or cross-platform mobile capture plus web review workspace | Accessibility, offline behavior, and health-platform permissions. |
| Canonical model | Event-oriented, FHIR-compatible clinical core plus user-defined observation layer | Forcing subjective symptoms into false clinical precision. |
| Raw vault | Immutable source documents and original payloads, separately protected | Retention, deletion, and high-value breach surface. |
| Normalization | Unit conversion, terminology mapping, deduplication, temporal alignment | Silent transformations and false merges. |
| Provenance graph | Explicit edges from source to normalized event to analysis to report statement | Complexity and performance; must remain inspectable. |
| Analytics | Descriptive statistics, pre-specified lag analysis, missingness and sensitivity views | P-hacking, spurious correlation, and user misinterpretation. |
| Literature layer | Curated authoritative sources plus peer-reviewed retrieval with versioned snapshots | Outdated, retracted, contradictory, or inapplicable evidence. |
| Personal knowledge graph | Separate verified facts, user observations, hypotheses, and evidence | Collapsing hypotheses into facts. |
| AI orchestration | Template-constrained generation, source grounding, citation entailment, deterministic policy checks | Model drift, prompt injection, and treatment leakage. |
| Reporting | One-page human-readable summary with source-linked appendix | Information overload and clinician distrust. |
| Evaluation and monitoring | Versioned ingestion, factuality, citation, safety, bias, privacy, and usability benchmarks | Shipping model changes without regression detection. |

Healthcare knowledge-graph research supports provenance-rich representations but also identifies persistent construction, interoperability, and evaluation challenges.[35] The knowledge graph should encode **contradiction, uncertainty, date, source class, population, and applicability**, not merely connect symptoms to diseases. The personal layer should remain distinct from the medical-evidence layer so that a user observation never becomes a clinical fact through repeated AI paraphrasing.

---

## 14. Business model and pricing

Basic consumer tracking is priced aggressively. Guava offers substantial aggregation and tracking in a free tier and displays Premium at US$8/month or US$78/year.[2] Bearable displays US$6.99/month or US$34.99/year with a free tier and discounts.[4] At the other end, PicnicHealth charges US$499/year for higher-touch record collection and support, with free access during eligible research studies and a US$149 connected-care visit.[9] Heads Up Health uses custom organizational pricing.[10] These benchmarks suggest that the market pays little for generic tracking, more for high-touch record retrieval or clinical workflow, and sometimes shifts cost to a sponsor.

A pure D2C subscription should be tested, not assumed. The chosen cohort has intense need but may have low energy, variable income, high support requirements, and episodic use around appointments. Employer distribution offers volume but creates surveillance concerns. Data monetization conflicts with the proposed trust moat. The most aligned sequence is **D2C outcome validation plus clinic, advocacy, or research-cohort sponsorship**, with strict separation between care support and research consent.

| Model | Strategic advantage | Structural weakness | Recommendation |
|---|---|---|---|
| Free organizational tier | Low-friction acquisition and trust building | Storage, support, and ingestion costs can be substantial | Limit scope; use it to demonstrate timeline value, not as an unlimited archive. |
| One-time appointment packet | Concrete outcome; easy willingness-to-pay test; aligns with episodic need | Revenue is event-driven and may not create habit | **Best first paid experiment.** |
| Recurring evidence workspace | Supports longitudinal retention and deeper analysis | Competes with low-cost trackers; cancellation risk between visits | Test after the one-time outcome proves value. |
| Clinic seat or per-active-patient fee | Clear distribution and potential workflow ROI | Sales cycle, integration burden, and clinician trust | Best second channel after report acceptance. |
| Advocacy-group sponsorship | Concentrated, trusted access and co-design | Limited budgets and governance obligations | Strong early research and distribution partner. |
| Research-cohort licensing | Can fund ingestion and evidence generation | Complex consent, protocol, and data-rights requirements | Later, with independent governance and explicit opt-in. |
| Employer or payer contract | Scale and larger budgets | Surveillance fears, long procurement, uncertain early ROI | Defer until outcomes, boundaries, and member protections are proven. |
| Advertising or health-data brokerage | Revenue without user payment | Directly undermines trust and creates regulatory exposure | **Reject.** |

### 14.1 Pricing experiments

The final plan should test three offers with qualified users rather than select a price from surveys alone:

| Offer | Value event | Test design |
|---|---|---|
| Free verified timeline | Imported and verified core history with limited sources | Measure completion, correction burden, and willingness to connect data. |
| Paid visit-preparation packet | One- to two-page report plus evidence appendix for a scheduled visit | Use real payment, multiple price points, and a refund policy; measure real-visit usefulness. |
| Recurring evidence workspace | Ongoing imports, associations, evidence cards, and report refreshes | Compare monthly and annual options; measure eight- and twelve-week retention rather than intent. |

Prices and conversion gates should remain assumptions until observed. The plan should report willingness to pay by income, disability status, condition severity, payer type, and support burden to avoid building a product accessible only to affluent users.

---

## 15. Go-to-market strategy

A trust-sensitive health product should not begin with broad paid acquisition. The best early channels are condition communities, advocacy organizations, specialty clinics, and credible patient educators, used for **co-design and outcome validation** rather than extraction. Participants and clinician reviewers should be compensated. Testimonials and personal health stories should require explicit, revocable consent.

| Stage | Channel | Offer | Evidence objective |
|---|---|---|---|
| 0. Discovery | Post-viral, POTS, fatigue, and multi-system communities; caregivers; primary and specialty clinicians | Interviews, workflow observation, and artifact co-design | Confirm problem frequency, language, trust barriers, and current workaround cost. |
| 1. Concierge pilot | 20–30 people with a scheduled real visit | Manually assisted verified timeline and evidence packet | Test factual accuracy, usefulness, burden, anxiety effects, and payment. |
| 2. Clinician validation | Primary care, cardiology, neurology, rheumatology, rehabilitation, and relevant allied care | Blinded report review and real-visit observation | Test readability, omission risk, review time, and workflow fit. |
| 3. Closed product pilot | One or two communities plus two to five clinics | Self-service import, verification, timeline, and report | Measure activation, extraction corrections, support cost, retention, and incidents. |
| 4. Paid launch | D2C appointment packet plus selected clinic partners | Concrete report outcome | Establish paid conversion, repeat use, channel economics, and referrals. |
| 5. Controlled expansion | Migraine, digestive symptoms, selected autoimmune or women’s-health cohorts | Reusable core with condition-specific evidence modules | Test whether the workflow transfers without broadening medical claims. |

The content strategy should focus on practical tasks—how to reconstruct a timeline, verify a lab import, document a medication change, or prepare for a specialist—rather than condition claims. Search and creator acquisition should send users to a useful artifact or guided import, not a generic “AI will find your root cause” landing page.

Clinic distribution should be attempted only after the report demonstrates a measurable benefit such as shorter pre-visit review, fewer factual clarifications, more complete medication history, or better prioritization of user goals. If the report merely transfers more unstructured data into the visit, it has failed.

---

## 16. Validation program and proposed gates

The following thresholds are **proposed decision gates**, not externally established standards. Clinical, regulatory, statistical, and user advisors should review them before adoption.

| Critical question | Method | Proposed gate to continue |
|---|---|---|
| Is the job frequent and painful? | At least 30 interviews across high-tracking patients, low-energy patients, caregivers, and clinicians | At least 70% of qualified patients independently describe timeline reconstruction or visit preparation as a recurring high-friction problem. |
| Can value be delivered without software? | Concierge production of 20–30 real packets | At least 70% report material improvement in preparation; fewer than 5% of included facts require material correction after final verification. |
| Do clinicians accept the artifact? | Blinded scoring plus observed real visits | At least 70% rate the summary useful or very useful; no critical safety omission; median review time at or below two minutes for the summary page. |
| Is ingestion trustworthy? | Benchmark across consented portal exports, PDFs, images, and health-platform data | More than 99% accuracy for verified critical fields after user review; every displayed fact is source-traceable. |
| Is correction understandable? | Moderated usability tests | At least 90% can find the source, identify provisional data, and correct an error without assistance. |
| Is burden acceptable? | Eight-week closed pilot | Median active logging below two minutes per day; at least 50% of activated users still contribute to or review their record in week eight. |
| Do users understand uncertainty? | Randomized comprehension test of alternative designs | At least 85% correctly distinguish association from causation and identify a displayed data limitation. |
| Is there willingness to pay? | Real purchase tests for packet and recurring workspace | A pre-specified conversion and contribution-margin threshold is met without deceptive urgency; results segmented by payer and socioeconomic factors. |
| Is AI contained within policy? | Fixed adversarial benchmark and expert review | Zero unblocked high-severity outputs involving diagnosis, medication changes, dangerous restriction, emergency reassurance, or fabricated citations. |
| Is the channel viable? | Two community and two clinic pilots | Support and acquisition cost fit a credible payback model; partner trust and participant satisfaction remain above pre-specified gates. |
| Does the product worsen anxiety? | Validated wellbeing measure, interviews, and usage signals | No clinically or practically meaningful deterioration attributable to the product; mitigations work when excessive checking appears. |

### 16.1 Concierge pilot design

The concierge pilot should intentionally simulate the proposed product while keeping humans responsible for verification. Each participant should provide a scheduled visit date, a small number of source documents or exports, medication history, principal goals, and permissioned wearable data if relevant. A trained researcher should create a source-linked timeline, identify conflicts, ask the participant to verify every critical field, produce only descriptive trends, retrieve literature with applicability notes, and generate non-ranked questions.

The pilot should record time spent by participant and operator, number and severity of extraction errors, missing-source events, support interactions, report edits, clinician review time, whether the packet changed visit priorities, willingness to pay, and anxiety or confusion. This produces the operating data needed to decide what to automate.

### 16.2 Evidence and safety evaluation

The evaluation set should include realistic records with duplicate labs, conflicting units, scanned images, changing reference ranges, edited medication dates, missing wearables, unusual abbreviations, and deliberately adversarial text embedded in documents. AI tests should include requests for a diagnosis, medication changes, supplement stacks, restrictive diets, emergency reassurance, pregnancy-related advice, pediatric use, self-harm or crisis content, and fabricated or retracted citations. The benchmark should be versioned and rerun for every model, prompt, retrieval-index, and policy change.

---

## 17. Moat and defensibility

The language model is not the moat. Models, retrieval libraries, OCR services, and FHIR connectors can be purchased. Accumulating sensitive data without governance can become a liability rather than an asset. The defensible system combines five mutually reinforcing capabilities:

| Moat component | Why it compounds | Why a competitor cannot copy it instantly |
|---|---|---|
| Provenance-rich longitudinal data model | Every correction and source relationship improves trustworthy downstream output | Requires ingestion, normalization, correction UX, and policy design across many source types. |
| Clinician-validated report format | Real workflow learning improves brevity, prioritization, and acceptance | Needs repeated observation across specialties and cannot be inferred from a feature list. |
| Contradiction-aware evidence graph | Links personal facts to dated, applicable, supporting and opposing evidence | Requires curation, evaluation, provenance, and domain governance beyond generic RAG. |
| Safety and quality evaluation system | Versioned tests create a release discipline and auditable trust claim | Competitors must invest continuously in benchmarks, adjudication, and post-market monitoring. |
| Trusted distribution and governance | Communities, clinics, and advocacy partners lower acquisition friction and improve design | Trust is relational and can be lost through privacy or overclaiming. |

Consented outcome data may improve the product later, but it should be collected under explicit purpose limitation and independent governance. “More user health data” should never be described as the moat without explaining rights, consent, deletion, access, bias, and benefit sharing.

---

## 18. Risk register and kill conditions

| Risk | Probability | Impact | Early warning | Mitigation | Pause or kill condition |
|---|---:|---:|---|---|---|
| Users treat hypotheses as diagnosis | High | Severe | Disease-seeking prompts, self-treatment, or misquotation of reports | Remove ranking, evidence ladder, comprehension testing, hard blocks | Severe unmitigated harm or repeated inability to prevent unsafe interpretation. |
| Feature becomes regulated medical-device functionality | Medium–high | Severe | Marketing or outputs recommend a diagnosis, test, or management action | Function-level counsel review; claims governance; possible FDA engagement | Required regulatory path exceeds available capital, timeline, or risk tolerance. |
| Unauthorized health-data disclosure | Medium | Severe | Health events appear in analytics, support, logs, or third-party SDKs | Data-flow inventory, isolation, least privilege, vendor review, incident drills | Architecture depends on nonessential disclosure or a critical unresolved control gap. |
| OCR or data reconciliation error | High | High | Incorrect value/unit/date enters a report | Provisional status, mandatory verification, source preview, correction history | Critical-field error rate cannot meet the pre-specified gate with usable effort. |
| Logging fatigue and abandonment | High | High | Setup drop-off and declining check-ins | Passive import, sparse prompts, value before logging, caregiver mode | Week-eight retention remains below the gate after two materially different designs. |
| Clinician rejection | Medium–high | High | Reports are ignored, too long, or anxiety-amplifying | Co-design, one-page summary, source appendix, specialty-specific testing | No repeatable workflow value or report increases visit burden. |
| Weak willingness to pay | High | High | High interest but low real payment or high support cost | Test event-based price, sponsorship, and clinic channel | No payer segment supports credible contribution margin after controlled tests. |
| Health anxiety or compulsive use | Medium | High | Repeated checking, distress, excessive notifications | Calm defaults, pause mode, bounded analytics, wellbeing monitoring | Meaningful harm persists despite mitigation. |
| Algorithmic bias and evidence mismatch | Medium | High | Evidence population does not resemble the user; unequal extraction or safety performance | Applicability display, subgroup evaluation, inclusive research, human review | Material disparities cannot be corrected before scale. |
| Competitive response | Medium | Medium–high | Guava or another platform adds cited evidence and clinician workflow | Win on provenance, validation, and partner trust; avoid broad feature race | The differentiated job is solved better by incumbents and no alternative wedge emerges. |

Privacy enforcement is not theoretical. FTC actions against Flo Health and GoodRx show the consequences of sending sensitive health information to advertising or analytics platforms in ways inconsistent with user representations.[46] [47] Digital-health company failures also show that clinical evidence or technical novelty does not repair weak reimbursement, poor workflow fit, or unsustainable economics. These lessons support a narrow, measured validation sequence rather than a capital-intensive platform launch.

---

## 19. Strategic options

| Option | Scope | Advantages | Risks | Decision |
|---|---|---|---|---|
| **A. Concierge evidence-and-visit service** | Human-assisted timeline, provenance, literature cards, and packet | Fast learning; low build cost; tests output, safety, and payment | Labor-intensive; not scalable by design | **Recommend first.** |
| **B. Consumer self-service workspace** | Mobile/web ingestion, verification, associations, evidence, and reporting | Scalable D2C product and reusable data layer | High technical, privacy, and safety complexity; crowded baseline | Build only after Option A meets gates. |
| **C. Clinic-sponsored workflow** | Clinic invites users; receives concise report | Distribution, repeat use, potential workflow ROI | Sales, integration, procurement, clinician liability concerns | Add after report acceptance and buyer discovery. |
| D. Broad root-cause platform | Ranking, pathways, tests, recommendations | Compelling marketing and potential willingness to pay | Highest harm, regulatory, liability, and credibility risk | **Reject for initial plan.** |
| E. Employer analytics | Sponsored access and population reporting | Large contracts | Surveillance concerns and trust conflict | Defer; prohibit individual employer access. |
| F. Research/data network | Consented cohorts and life-sciences partnerships | Non-D2C revenue and evidence generation | Complex consent and mission drift | Consider later under separate governance. |

### Recommendation

**Approve Option A as the only immediate program.** Its purpose is to validate the problem, output, safety boundary, workflow, and willingness to pay—not to simulate certainty or pre-sell an unbuilt platform. Use the results to decide whether Option B has sufficient value to justify the privacy and engineering burden. Advance to Option C only if clinicians demonstrate measurable benefit and a payer is identified.

---

## 20. Staged roadmap for the final plan

| Stage | Duration assumption | Deliverable | Decision gate |
|---|---|---|---|
| 1. Discovery and governance | 4–6 weeks | User/clinician interviews, claims inventory, initial safety policy, data-flow map, regulatory memo | The job is frequent and the conservative product boundary remains valuable. |
| 2. Concierge validation | 6–10 weeks | 20–30 verified packets for real visits; payment and clinician review | Accuracy, usefulness, burden, and payment meet pre-specified thresholds. |
| 3. Technical spikes | 4–8 weeks, partly parallel after validation | HealthKit/Health Connect proof, FHIR coverage map, OCR benchmark, provenance model, report prototype | Ingestion quality and cost are viable; no critical privacy architecture gap. |
| 4. Closed MVP | 12–16 weeks | Timeline, selected imports, verification, descriptive trends, evidence cards, report, trust controls | Activation, week-eight engagement, safety, correction burden, and clinician acceptance meet gates. |
| 5. Paid cohort launch | 8–12 weeks | One or two communities and selected clinic partners | Paid conversion, support cost, referrals, and incident rate support controlled growth. |
| 6. Adjacent expansion | Evidence-dependent | One new cohort or one new channel at a time | The core workflow transfers without broadening unsafe claims. |

These durations are planning assumptions, not commitments. The roadmap should remain milestone-based. If the concierge pilot disproves the core job or clinicians reject the packet, the company should pivot before building an extensive ingestion and AI platform.

---

## 21. Inputs Claude Fable should use—and should not assume

### Confirmed inputs

| Input | Status |
|---|---|
| Aggregation, tracking, correlations, AI summaries, guided pathways, and visit reports already exist across competitors. | Confirmed from official product materials. |
| The large multimorbidity population establishes need but not purchasing demand. | Confirmed denominator; commercial conversion unknown. |
| Consumer health apps may fall outside HIPAA while remaining subject to FTC and state obligations. | Confirmed regulatory principle. |
| Observational self-tracking does not, by itself, establish causality. | Confirmed scientific principle. |
| Multi-route ingestion is necessary; no universal API supplies a complete record. | Confirmed technical constraint. |
| Basic consumer tracking faces a free-to-low-cost benchmark. | Confirmed pricing signal. |

### Assumptions Claude Fable must preserve as assumptions

| Assumption | Required validation |
|---|---|
| The proposed cohort values a provenance-first report more than existing tools. | Concierge pilot and competitor win/loss interviews. |
| Clinicians will read and use the report. | Blinded review and observed visits. |
| Users understand and value evidence citations and uncertainty. | Comprehension and willingness-to-pay testing. |
| A one-time appointment packet can acquire users profitably. | Real payment and channel experiments. |
| Clinic sponsorship has a budget owner and positive ROI. | Buyer interviews and limited paid pilots. |
| Contradiction-aware retrieval can meet medical safety and factuality gates. | Curated benchmark and expert adjudication. |
| The product can remain outside medical-device regulation in its intended form. | Jurisdiction-specific counsel and function-level analysis. |

### Prohibited planning shortcuts

The final plan should not use top-down market-report revenue as the central TAM; assume complete EHR connectivity; call public-source gaps confirmed absences; promise diagnosis or root-cause discovery; treat RAG as a hallucination solution; assume HIPAA is the entire privacy regime; claim true end-to-end encryption while cloud AI receives plaintext; or put the full vision into a single MVP.

---

## 22. Acceptance criteria for the Claude Fable plan

The final plan should be accepted only if it:

1. Reframes the product away from broad root-cause and generic AI positioning.
2. Defines one job-based wedge and one initial cohort.
3. Distinguishes confirmed competitor capabilities, unverified gaps, and assumptions.
4. Begins with concierge and clinician validation before substantial software investment.
5. Includes the evidence ladder and prohibited-output policy as product requirements.
6. Uses bottom-up channel economics rather than a headline market-report TAM.
7. Treats privacy, consent, provenance, and deletion as architecture.
8. Includes jurisdiction and function-specific regulatory gates.
9. Defines measurable activation, accuracy, burden, clinician-usefulness, payment, safety, and anxiety thresholds.
10. Includes explicit exclusions, kill conditions, and a decision branch if the core job fails.
11. Separates D2C, clinic, advocacy, employer, and research economics.
12. Does not present the entire “second brain” vision as the MVP.

---

## 23. Final conclusion

There is a credible company concept inside the original idea, but it is **not a generic personal health second brain and not a root-cause engine**. Those descriptions hide several distinct, crowded categories and invite unsafe expectations. The opportunity is to become the trust layer between fragmented personal data, medical evidence, and a short clinical conversation.

The proposed company should earn the right to build that layer by proving four things in order: users can create an accurate longitudinal story with tolerable effort; clinicians can understand and use the result; evidence retrieval improves questions without creating false certainty; and a payer will fund the outcome without compromising privacy. If those gates are met, a provenance-first evidence workspace can expand from visit preparation into a durable personal health knowledge system. If they are not met, the broad platform should not be built.

---

## References

[1]: https://guavahealth.com/ "Guava Health — official product site"
[2]: https://guavahealth.com/plans "Guava Health — Plans & Pricing"
[3]: https://bearable.app/ "Bearable — official product site"
[4]: https://bearable.app/our-pricing-and-principles/ "Bearable — Our Pricing and Principles"
[5]: https://www.human.health/ "Human Health — official product site"
[6]: https://careclinic.io/ "CareClinic — official product site"
[7]: https://www.makevisible.com/ "Visible — official product site"
[8]: https://headsuphealth.com/product/ "Heads Up Health — AI-Powered Clinical Intelligence Platform"
[9]: https://picnichealth.com/pricing "PicnicHealth — Pricing"
[10]: https://headsuphealth.com/pro-pricing/ "Heads Up Health — Professional Pricing"
[11]: https://onerecord.com/ "OneRecord — official product site"
[12]: https://seqster.com/ "Seqster — official product site"
[13]: https://www.patientslikeme.com/about "PatientsLikeMe — About Us"
[14]: https://www.openhumans.org/about/ "Open Humans — About"
[15]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10582809/ "Comparison of diagnostic and triage accuracy of Ada Health and other symptom assessment applications"
[16]: https://www.fda.gov/regulatory-information/search-fda-guidance-documents/clinical-decision-support-software "FDA — Clinical Decision Support Software Guidance"
[17]: https://www.fda.gov/medical-devices/software-medical-device-samd/clinical-decision-support-software-frequently-asked-questions-faqs "FDA — Clinical Decision Support Software FAQs"
[18]: https://www.fda.gov/regulatory-information/search-fda-guidance-documents/general-wellness-policy-low-risk-devices "FDA — General Wellness: Policy for Low Risk Devices"
[19]: https://www.ftc.gov/business-guidance/resources/complying-ftcs-health-breach-notification-rule-0 "FTC — Complying with the Health Breach Notification Rule"
[20]: https://www.ftc.gov/business-guidance/advertising-marketing/health-claims "FTC — Health Claims"
[21]: https://www.hhs.gov/hipaa/for-professionals/special-topics/health-apps/index.html "HHS — Resources for Mobile Health Apps Developers"
[22]: https://www.ftc.gov/business-guidance/resources/mobile-health-apps-interactive-tool "FTC/HHS/FDA — Mobile Health Apps Interactive Tool"
[23]: https://www.cdc.gov/pcd/issues/2025/24_0539.htm "CDC Preventing Chronic Disease — Trends in Multiple Chronic Conditions, 2013–2023"
[24]: https://www.cdc.gov/chronic-disease/about/index.html "CDC — About Chronic Diseases"
[25]: https://www.cdc.gov/pcd/issues/2024/23_0267.htm "CDC Preventing Chronic Disease — Geographic and socioeconomic chronic-disease burden"
[26]: https://pmc.ncbi.nlm.nih.gov/articles/PMC6087468/ "Causal inference for self-tracked time-series data"
[27]: https://arxiv.org/html/2406.10360v2 "Causal inference in N-of-1 trials with time-varying processes"
[28]: https://pmc.ncbi.nlm.nih.gov/articles/PMC6032822/ "Wearable sensors in clinical trials: analytical and clinical validation"
[29]: https://build.fhir.org/ig/HL7/smart-app-launch/ "HL7 — SMART App Launch Implementation Guide"
[30]: https://www.cms.gov/priorities/burden-reduction/overview/interoperability/frequently-asked-questions/patient-access-api "CMS — Patient Access API Frequently Asked Questions"
[31]: https://developer.apple.com/documentation/healthkit "Apple Developer — HealthKit"
[32]: https://developer.android.com/health-and-fitness/health-connect "Android Developers — Health Connect"
[33]: https://pmc.ncbi.nlm.nih.gov/articles/PMC12059965/ "Retrieval-augmented generation in healthcare"
[34]: https://link.springer.com/chapter/10.1007/978-3-032-21289-4_3 "Contradictions in Context: Challenges for Retrieval-Augmented Generation in Healthcare"
[35]: https://pmc.ncbi.nlm.nih.gov/articles/PMC10225120/ "Healthcare knowledge graph construction: systematic review"
[36]: https://aspe.hhs.gov/conceptualizing-data-infrastructure-capture-use-patient-generated-health-data "HHS ASPE — Data infrastructure for patient-generated health data"
[37]: https://hdsr.mitpress.mit.edu/pub/dsu525z7/release/1 "Personalized Data Science and N-of-1 Trials"
[38]: https://dl.acm.org/doi/fullHtml/10.1145/3313831.3376809 "Trackly: Customisable self-tracking for multiple sclerosis self-care"
[39]: https://www.reddit.com/r/ChronicIllness/comments/1cougu4/does_anyone_have_experience_with_the_app_bearable/ "Reddit r/ChronicIllness — Bearable user discussion (qualitative only)"
[40]: https://www.reddit.com/r/ChronicIllness/comments/1iys9oq/guava_health_vs_bearable/ "Reddit r/ChronicIllness — Guava versus Bearable discussion (qualitative only)"
[41]: https://www.trustpilot.com/review/guavahealth.com "Trustpilot — Guava reviews (small, non-representative sample)"
[42]: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/lawful-basis/special-category-data/what-is-special-category-data/ "UK ICO — What is special category data?"
[43]: https://www.gov.uk/government/publications/software-and-artificial-intelligence-ai-as-a-medical-device/software-and-artificial-intelligence-ai-as-a-medical-device "UK MHRA — Software and AI as a medical device"
[44]: https://www.oaic.gov.au/privacy/your-privacy-rights/health-information "OAIC — Health information"
[45]: https://www.tga.gov.au/resources/guidance/understanding-how-we-regulate-software-based-medical-devices "TGA — Regulation of software-based medical devices"
[46]: https://www.ftc.gov/news-events/news/press-releases/2021/01/ftc-finalizes-order-flo-health-data-sharing "FTC — Flo Health data-sharing order"
[47]: https://www.ftc.gov/news-events/news/press-releases/2023/02/ftc-enforcement-action-bar-goodrx-sharing-consumers-sensitive-health-info-advertising "FTC — GoodRx health-data enforcement action"

