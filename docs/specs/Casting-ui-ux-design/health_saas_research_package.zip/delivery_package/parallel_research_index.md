# Parallel Research Index

**Workstreams:** 36
**Parsed source citations:** 219
**Unique source URLs:** 192

## Evidence quality

| Rating | Workstreams |
|---|---:|
| High | 23 |
| Medium | 13 |

## Workstream findings

### 1. Chronic-illness user needs, jobs-to-be-done, current workarounds, trust barriers, and willingness-to-pay signals

Chronic illness patients face a significant unmet need for customizable, non-medicalized self-tracking tools that support their sense of agency and accommodate idiosyncratic symptoms. While there is a strong desire to share health data for research and care improvement, significant trust barriers exist regarding privacy, data leakage, and the loss of control over personal health records. Willingness to pay is closely tied to an individual's attitude towards self-management and the perceived value of the technology in improving their functioning and independence.

**Evidence quality:** Medium — The evidence relies on a mix of peer-reviewed HCI/informatics studies and industry reports, providing a solid foundation on user needs and behaviors, but specific willingness-to-pay data for complex SaaS solutions remains limited.

### 2. Patient-controlled longitudinal health-record and personal health record market landscape

The market for patient-controlled longitudinal health records is highly fragmented, with consumer-facing apps excelling at symptom tracking but struggling with comprehensive clinical data aggregation, while enterprise platforms offer robust aggregation but lack consumer-friendly "second brain" features. A defensible gap exists for a privacy-first, consumer-controlled platform that bridges deep clinical data aggregation with advanced, conservative AI-driven insights and practitioner collaboration tools. Success depends on navigating high trust barriers and regulatory complexities of consumer health data.

**Evidence quality:** Medium — The analysis relies on current official product pages and market reports, providing a solid overview of features and positioning, but lacks deep independent clinical validation or internal user retention metrics.

### 3. N-of-1 trials, quantified-self methods, symptom correlation, and limits of causal inference

N-of-1 trials and quantified-self methods offer a promising paradigm for personalized health by allowing individuals to act as their own investigators and beneficiaries. However, causal inference from self-tracked observational data is fundamentally limited by nonstationary time series, symptom heterogeneity, and latent confounding. Therefore, a personal health SaaS must adopt a conservative approach to symptom correlation, focusing on hypothesis generation and clear uncertainty communication rather than definitive causal claims.

**Evidence quality:** Medium — The findings are based on recent peer-reviewed academic literature and methodological papers, but lack direct commercial product data for this specific workstream.

### 4. Guava Health competitor deep dive

Guava Health is a highly regarded, free-first personal health tracker that excels at aggregating medical records from patient portals and wearable data into a single searchable interface, particularly for chronic illness patients. However, it functions strictly as a passive data aggregator and correlation engine without offering its own clinical testing, diagnostic capabilities, or direct treatment recommendations. Its reliance on user-generated data and third-party integrations presents a strategic gap for a 'second brain' SaaS to differentiate by offering more active, evidence-backed hypothesis generation and clinician-guided pathway exploration.

**Evidence quality:** High — Findings are based on official Guava Health documentation, pricing pages, privacy policies, and aggregated user reviews from credible sources.

### 5. Bearable competitor deep dive

Bearable is a highly customizable, patient-founded symptom and mood tracker that excels at manual data collection and correlation discovery for chronic illness management, but it remains strictly a mobile-only self-tracking tool without clinical integration, web access, or automated medical record aggregation. Its reliance on manual entry creates a high cognitive burden for users, presenting a clear opportunity for a SaaS that automates data ingestion and bridges the gap between patient-generated data and clinical care.

**Evidence quality:** High — Findings are based on Bearable's official website, privacy policy, App Store listing, and corroborated by independent reviews and user discussions.

### 6. CareClinic competitor deep dive

CareClinic is a feature-rich, highly structured symptom and health tracker that emphasizes clinical frameworks, care plans, and detailed correlation tracking. However, its aggressive monetization strategy (heavy paywalls for basic features) and cluttered user interface present significant friction for users. A competing "second brain" SaaS can differentiate by offering a more intuitive, user-centric design, transparent pricing, and a stronger focus on patient empowerment rather than top-down clinical compliance.

**Evidence quality:** High — Findings are based on CareClinic's official website, privacy policy, and a detailed third-party review (Bearable), providing a comprehensive view of features, pricing, and user experience.

### 7. Human Health competitor deep dive

Human Health offers a robust, genuinely free symptom and treatment tracker with a massive symptom library and PDF provider reports, setting a high baseline for consumer expectations. However, its reliance on manual data entry, lack of wearable/lab integrations, and shallow treatment-correlation tools present clear opportunities for a 'second brain' SaaS. To compete, a new entrant must prioritize automated data ingestion and advanced, yet safe, correlation insights to justify a subscription model.

**Evidence quality:** High — Findings are based on the official product website, help center, privacy policy, and a recent comprehensive third-party review aggregating user sentiment.

### 8. Visible competitor deep dive

Visible has successfully carved out a defensible niche in the energy-limiting chronic illness market by explicitly rejecting fitness-tracker paradigms in favor of a "pacing" and "energy budgeting" model using continuous heart rate monitoring. However, its strict reliance on its proprietary Polar armband (rejecting Apple Watch/Garmin integration) and its simplistic biometric model (which struggles with non-cardiac neurological crashes like FND) present significant gaps. A competing personal health SaaS can differentiate by offering hardware-agnostic integrations, multi-system symptom correlation (beyond just HR/HRV), and a more sophisticated pathway explorer that accommodates diverse condition profiles.

**Evidence quality:** High — based on direct analysis of Visible's official website, privacy policy, terms of service, and independent user reviews from Trustpilot and Reddit.

### 9. Heads Up Health competitor deep dive

Heads Up Health is primarily a B2B2C clinical intelligence platform designed for concierge, longevity, and functional medicine practices, rather than a pure consumer self-tracking app. While it excels at unifying diverse data streams (EHRs, labs, wearables) into a single practitioner dashboard, its consumer-facing features are secondary and lack the personalized, evidence-backed hypothesis generation required for a true 'second brain'. The platform's pivot towards AI agents and enterprise pricing leaves a significant gap in the market for an affordable, consumer-first tool that empowers patients to independently analyze their longitudinal health data.

**Evidence quality:** High — Findings are based on the competitor's current official product pages, pricing pages, legal documents, and corroborated by independent reviews.

### 10. Exist.io, Flaredown, mySymptoms, and comparable correlation-tracking tools

The correlation-tracking market is divided between general quantified-self tools (Exist.io) and condition-specific trackers (Flaredown, mySymptoms, Bearable, Guava). While these tools excel at data aggregation and basic statistical correlation, they explicitly avoid clinical claims and struggle with the burden of manual data entry. A defensible gap exists for a platform that combines automated data ingestion (like Guava) with rigorous, conservative hypothesis generation that bridges the gap between patient-tracked correlations and clinical evidence, without crossing into regulated diagnostic territory.

**Evidence quality:** High — Findings are based directly on official product pages, privacy policies, and app store descriptions current as of 2024-2026.

### 11. Ornament and comparable lab-result interpretation and tracking apps

The market for lab-result interpretation apps like Ornament and Carrot Care is transitioning from simple digitization to AI-driven insights and habit formation, yet users frequently report issues with OCR accuracy and unexpected price increases. A significant opportunity exists for a health SaaS that reliably integrates lab data with broader health metrics (wearables, symptoms) while maintaining transparent pricing and rigorous, conservative clinical boundaries. The proposed SaaS should prioritize flawless data ingestion and clear, evidence-backed explanations over aggressive weight-loss or diagnostic claims.

**Evidence quality:** Medium — Based on official app store listings, developer websites, and user reviews, providing a solid overview of features and limitations, though independent clinical validation is lacking.

### 12. InsideTracker, Function Health, and consumer biomarker-personalization services

The consumer biomarker market is bifurcating into affordable data-only platforms (Function Health, InsideTracker) and premium continuous-optimization services that include prescriptions and supplements (OneTwenty, Life Force). A significant unmet need exists for a middle-ground solution that bridges the gap between raw biomarker data and actionable, continuous clinical care without the high cost of concierge services. The integration of continuous wearable data with periodic blood testing is becoming the new standard for proactive health management.

**Evidence quality:** High — Findings are based on recent (2025-2026) detailed reviews, direct comparisons, and official pricing/feature data from multiple independent sources.

### 13. PicnicHealth, Seqster, OneRecord, Apple Health Records, and health-record aggregation alternatives

The health-record aggregation market is bifurcated between enterprise/research-focused platforms (Seqster, PicnicHealth) and consumer-centric, API-driven tools (Apple Health, OneRecord). While robust infrastructure exists for retrieving and standardizing data via FHIR and SMART on FHIR, a significant gap remains for a consumer-facing SaaS that not only aggregates records but also provides actionable, evidence-backed hypothesis generation and longitudinal self-tracking without crossing into regulated clinical decision support.

**Evidence quality:** High — Findings are based on official product pages, API documentation, and direct platform descriptions from the companies' own websites.

### 14. PatientsLikeMe, StuffThatWorks, Open Humans, and community or research substitutes

Existing community and research platforms successfully aggregate patient-reported outcomes and foster peer support, but they struggle to bridge the gap between subjective crowdsourced data and rigorous clinical utility. A significant opportunity exists for a health SaaS that combines the engagement of community platforms with verifiable, longitudinal health records and conservative, evidence-backed pathway exploration, avoiding the pitfalls of unverified medical claims.

**Evidence quality:** Medium — Findings are based on official company pages, privacy policies, press releases, and academic literature, but lack deep independent clinical validation of their AI/efficacy claims.

### 15. Ada, K Health, Buoy, Healthily, and symptom-checker substitutes

Current symptom checkers (Ada, K Health, Buoy, Healthily) excel at point-in-time triage and preliminary assessment but fail to provide longitudinal tracking, deep clinical record integration, or patient-controlled "second brain" capabilities. A defensible gap exists for a SaaS that bridges the divide between episodic symptom checking and continuous, evidence-backed health management, provided it strictly avoids diagnostic claims and navigates regulatory boundaries carefully.

**Evidence quality:** Medium — Findings are based on official privacy policies, terms of service, and peer-reviewed literature, but lack direct user interviews or proprietary market data.

### 16. Practice Better, Fullscript, Rupa Health, and practitioner or functional-medicine workflow alternatives

Practice Better, Fullscript, and Rupa Health dominate the practitioner-facing functional medicine workflow by solving administrative, dispensing, and lab-ordering friction, but they remain fundamentally B2B tools designed for clinician control rather than patient autonomy. A consumer-facing "second brain" SaaS has a clear defensible gap if it focuses on patient-led longitudinal tracking, cross-provider data aggregation, and hypothesis generation, areas where current EHRs and dispensaries are structurally disincentivized to innovate due to their practitioner-centric business models.

**Evidence quality:** High — Findings are based on official product pages, pricing tiers, and recent independent reviews from credible healthcare technology platforms.

### 17. Obsidian, Notion, spreadsheets, and DIY personal-health knowledge-base substitutes

Highly motivated chronic-illness patients are building complex, manual health-tracking systems in Obsidian, Notion, and spreadsheets because existing apps fail to provide flexible, cross-domain correlation (e.g., linking diet, sleep, and symptoms). While these DIY tools offer ultimate customization and data ownership, they suffer from high friction in data entry, lack of automated insights, and inability to integrate seamlessly with clinical records or wearables. A purpose-built SaaS that combines the flexibility and relational power of these tools with automated data ingestion and clinical safety guardrails represents a strong opportunity.

**Evidence quality:** Medium — Findings are based on user forums, template descriptions, and DIY community discussions, which accurately reflect current user behaviors and workarounds, but lack formal clinical or market studies on this specific niche.

### 18. Consumer reviews and complaint patterns for leading tracking and personal-health-record apps

Leading health tracking apps excel at data input and records aggregation but frequently fail at making this data useful for clinical consultations. Users highly value the ability to consolidate medical records and track complex symptoms, but they are frustrated by cluttered interfaces, paywalls, and the inability to easily share actionable insights with their doctors. There is a significant unmet need for a platform that bridges the gap between patient-generated data and physician-facing output.

**Evidence quality:** High — The findings are based on a synthesis of direct user reviews, app store ratings, independent UX benchmarking, and product documentation from leading health tracking apps.

### 19. Competitive feature and pricing benchmarks across direct and adjacent products

The consumer health tracking market is bifurcated into low-cost symptom trackers (e.g., Bearable, Human Health) and higher-priced, data-aggregating platforms (e.g., Guava Health, Heads Up Health). A significant gap exists for a "second brain" SaaS that bridges comprehensive data aggregation with actionable, evidence-backed hypothesis generation and clinician collaboration, provided it can navigate the regulatory boundaries of clinical decision support. The prevailing consumer willingness to pay is low ($7-$10/month), suggesting that monetization may require a B2B2C model or targeting highly motivated chronic illness segments.

**Evidence quality:** High — Pricing and feature data were extracted directly from official product websites and verified through current app store listings and independent reviews.

### 20. Evidence-search and medical-literature tools such as OpenEvidence, Consensus, Elicit, and Examine

Current evidence-search tools like OpenEvidence, Consensus, Elicit, and Examine provide robust, cited answers from medical literature but operate as standalone platforms disconnected from personal health data. A significant opportunity exists to integrate rigorous, sentence-level cited evidence retrieval with longitudinal self-tracking, provided the system strictly maintains a "no medical advice" boundary and utilizes transparent uncertainty markers.

**Evidence quality:** High — Findings are based on official product pages, academic reviews, and published studies (e.g., Nature Medicine) evaluating these tools.

### 21. Scientific evidence for knowledge graphs, longitudinal phenotyping, and patient-generated health data

Scientific evidence supports the potential of Patient-Generated Health Data (PGHD), longitudinal phenotyping, and Healthcare Knowledge Graphs (HKGs) to transform personalized care, particularly for lifestyle-related chronic conditions. However, the integration of PGHD into Electronic Health Records (EHRs) remains in its infancy, hindered by interoperability challenges, privacy concerns, and the need for standardized data delivery. A personal health SaaS must prioritize robust, clinically grounded knowledge graphs to preserve clinical intent and ensure data continuity across the care journey, while addressing the significant barriers to clinical adoption.

**Evidence quality:** Medium — Findings are based on recent systematic reviews and scoping reviews, but the literature highlights that clinical integration of these technologies is still in early stages with limited real-world implementation data.

### 22. Safety design for hypothesis generation, uncertainty communication, red-flag escalation, and human oversight

While AI-driven symptom checkers and clinical decision support systems (CDSS) show promise in hypothesis generation and pre-visit intake, autonomous diagnostic triage remains fraught with safety risks and variable performance. The most decision-relevant conclusion is that a personal health SaaS must implement conservative red-flag escalation, transparent uncertainty communication, and explicit human-in-the-loop oversight to mitigate liability and patient harm. This approach avoids autonomous clinical decision-making that triggers strict medical device regulation.

**Evidence quality:** Medium — The findings are supported by recent peer-reviewed literature, scoping reviews, and official FDA guidance, but the rapid evolution of LLMs in healthcare means long-term real-world safety data is still emerging.

### 23. United States FDA boundary analysis for wellness, clinical decision support, and software as a medical device

The FDA explicitly excludes low-risk general wellness products and certain Clinical Decision Support (CDS) software from medical device regulation, provided they do not make specific disease treatment/diagnosis claims or require healthcare professionals to rely primarily on their recommendations. For a personal health SaaS, features like longitudinal tracking, symptom correlation, and evidence retrieval can remain unregulated if they focus on general wellness, encourage healthy lifestyle choices related to chronic conditions, and present information in a way that enables independent review rather than directing clinical action. However, features that analyze medical signals, provide specific diagnostic pathways, or prompt specific medical management cross the boundary into regulated Software as a Medical Device (SaMD).

**Evidence quality:** High — Findings are based directly on final FDA guidance documents and IMDRF frameworks, which are the authoritative sources for regulatory boundaries.

### 24. United States HIPAA, FTC Health Breach Notification Rule, state consumer-health-data laws, and liability exposure

The regulatory landscape for consumer health apps has shifted dramatically, moving away from a "HIPAA-exempt means unregulated" paradigm to a strict framework governed by the FTC's expanded Health Breach Notification Rule and aggressive state laws like Washington's My Health My Data Act. A personal health SaaS must architect for opt-in consent, strict data segregation, and avoid unauthorized third-party sharing (which the FTC now classifies as a "breach"), while carefully positioning its Root Cause & Pathway Explorer as a "general wellness" tool to avoid FDA medical device classification. The presence of a private right of action in Washington creates immediate, high-risk litigation exposure for non-compliance.

**Evidence quality:** High — Findings are based directly on official guidance from HHS, FTC, FDA, and comprehensive legal analyses from reputable law firms regarding recent state privacy laws.

### 25. European Union GDPR, Medical Device Regulation, AI Act, and health-app implications

A personal health SaaS targeting EU users faces a complex, overlapping regulatory landscape where health data processing requires explicit GDPR Article 9 consent and breach notification within 72 hours. If the app's features cross into diagnostic, therapeutic, or clinical monitoring purposes, it will be classified as a medical device under the MDR (likely Class IIa or higher under Rule 11), which in turn triggers "high-risk" classification under the new EU AI Act if AI is used. To remain unregulated as a medical device, the MVP must strictly limit its functionality to general wellness, administrative tracking, or simple data display without clinical decision support or automated hypothesis generation.

**Evidence quality:** High — Findings are based on direct analysis of EU regulations (GDPR, MDR, AI Act) and expert legal/regulatory interpretations from specialized consultancies.

### 26. United Kingdom and Australian health-data, medical-device, and consumer-protection implications

Both the UK and Australia strictly regulate health data as sensitive/special category information, requiring explicit consent and robust security under the UK GDPR and Australian Privacy Act. Furthermore, both the UK MHRA and Australian TGA classify software that performs diagnosis, clinical monitoring, or treatment recommendations as a regulated medical device (SaMD), meaning a "conservative Root Cause & Pathway Explorer" must be carefully designed to avoid triggering stringent pre-market approval requirements.

**Evidence quality:** High — Findings are based directly on official regulatory guidance from the UK MHRA, UK ICO, Australian TGA, and Australian OAIC.

### 27. Privacy architecture, end-to-end encryption, key management, search on encrypted data, deletion, portability, and auditability

A defensible privacy architecture for a personal health SaaS must implement application-layer end-to-end encryption (E2EE) with searchable encryption capabilities to protect sensitive data while maintaining usability. Regulatory compliance requires strict adherence to data deletion and portability mandates, such as the Washington My Health My Data Act (MHMDA) and GDPR, balancing the right to erasure with medical record retention exemptions. Implementing robust key management and comprehensive auditability will differentiate the product from competitors that lack true E2EE and expose user data to legal and security risks.

**Evidence quality:** High — Findings are grounded in current regulatory frameworks (GDPR, Washington MHMDA), established technical solutions (IronCore Labs), and authoritative reports (OECD).

### 28. Interoperability architecture: FHIR, SMART on FHIR, Apple Health and HealthKit, laboratory imports, OCR, and provenance

A viable interoperability architecture for a personal health SaaS must combine a mobile-first Apple HealthKit integration for continuous biometric/device data with SMART on FHIR for secure, consent-driven clinical record retrieval. Because HealthKit lacks a backend API and FHIR adoption remains uneven, the system must also incorporate AI-powered OCR (achieving 95-99% accuracy) to digitize legacy or non-standardized lab reports and discharge summaries. Robust data provenance tracking is essential to maintain trust and clinical safety when merging these disparate data sources.

**Evidence quality:** High — Findings are grounded in official documentation (Apple Developer, CMS/ONC standards via Fire.ly/Kodjin) and recent industry benchmarks for OCR and interoperability.

### 29. Safe AI and retrieval-augmented generation architecture for medical literature retrieval, citation verification, calibration, and hallucination controls

Retrieval-Augmented Generation (RAG) significantly reduces AI hallucinations in medical applications by grounding outputs in external literature, but it is not a standalone solution. Safe AI in healthcare requires a multi-layered approach combining RAG with knowledge graphs, specialized evaluation metrics, and human-in-the-loop oversight to mitigate risks from outdated or contradictory sources. Contradictions in retrieved context can degrade model performance, highlighting the need for contradiction-aware filtering.

**Evidence quality:** High — Findings are based on recent systematic reviews and peer-reviewed studies evaluating RAG in healthcare.

### 30. Health knowledge-graph and pathway-model architecture, including ontology and provenance options

The architecture for a personal health "second brain" must integrate a Personal Health Knowledge Graph (PHKG) with a flexible, ontology-driven pathway model to effectively synthesize longitudinal patient data and medical evidence. While clinical pathways are well-established in institutional settings, adapting them for consumer self-tracking requires a conservative approach that separates static domain knowledge (medical facts) from dynamic task knowledge (problem-solving processes) to ensure safety and avoid crossing into regulated clinical decision support. Provenance tracking and human-in-the-loop oversight are critical to mitigate the risks of AI hallucination and ensure trust in hypothesis generation.

**Evidence quality:** Medium — The research relies on peer-reviewed academic papers and systematic reviews, but practical implementations in consumer SaaS are still emerging and lack extensive commercial validation.

### 31. Market-size proxies, category growth, and defensible bottom-up TAM, SAM, and SOM methods

The personal health record (PHR) and mHealth markets are growing at ~10-14% CAGR, driven by patient demand for centralized health data and wearable integration. However, top-down market sizes ($11B+ for PHR) are insufficient for venture validation; a defensible bottom-up TAM/SAM/SOM model must be built on specific condition wedges (e.g., chronic disease management), clear buyer personas, and realistic capture rates rather than broad industry figures.

**Evidence quality:** Medium — Market size estimates vary widely between research firms, but the underlying growth drivers and bottom-up sizing methodologies are well-established in venture capital practices.

### 32. Business models, pricing, unit-economics constraints, and practitioner-versus-consumer monetization

The consumer health SaaS market is highly fragmented, with pure D2C models struggling with high acquisition costs and low willingness to pay, often relying on freemium models with low conversion rates. Successful monetization increasingly relies on B2B2C models (partnering with employers, payors, or health systems) or monetizing aggregated, de-identified patient data for life sciences research. Practitioner-facing tools demonstrate stronger unit economics through clear ROI (time savings, revenue generation) and established SaaS pricing tiers.

**Evidence quality:** High — Findings are based on direct review of official pricing pages, terms of service, and recent press releases from the companies themselves.

### 33. Go-to-market routes through condition communities, clinicians, creators, employers, research partners, and advocacy groups

A multi-channel B2B2C go-to-market strategy targeting self-insured employers and condition-specific patient communities offers the most viable path to scale for a personal health "second brain" SaaS. While direct-to-consumer (D2C) acquisition is costly and challenging due to high churn and trust barriers, partnering with employers provides recurring revenue and bulk user acquisition. Furthermore, clinical research partnerships and advocacy groups build essential credibility and evidence for long-term defensibility.

**Evidence quality:** Medium — The findings are supported by credible industry reports, consulting frameworks, and competitor analyses, but lack direct primary data on the specific willingness-to-pay for a "second brain" concept among employers.

### 34. Condition-wedge comparison across eczema, digestive disorders, fatigue or Long COVID, migraine, autoimmune conditions, and women’s health

The most viable condition wedge for a personal health SaaS is energy-limiting conditions (Long COVID, ME/CFS) or complex autoimmune/digestive disorders, where patients face high diagnostic uncertainty and require longitudinal tracking. However, strict adherence to FDA guidelines is necessary to avoid classification as a medical device, meaning the platform must focus on data aggregation and correlation rather than diagnostic or treatment recommendations. A defensible gap exists in combining passive wearable data (like Visible) with comprehensive health record aggregation (like Guava) for these specific patient populations.

**Evidence quality:** Medium — Relies on official product pages, FDA guidance, and market reports, but lacks direct user interviews or proprietary clinical trial data.

### 35. Clinical validation, quality-management, post-market monitoring, and evidence-generation roadmap

The regulatory landscape for digital health is shifting from rigid pre-market clinical evaluation frameworks to a total product lifecycle approach emphasizing risk-based oversight, real-world evidence generation, and continuous post-market monitoring. For a personal health "second brain" SaaS, success depends on implementing a robust Quality Management System (e.g., ISO 13485) and an Integrated Evidence Plan that aligns clinical validation with payer and provider requirements while carefully managing the boundary between wellness tracking and regulated Software as a Medical Device (SaMD).

**Evidence quality:** High — The findings are grounded in official regulatory guidance (FDA, NICE), established industry frameworks (DiMe, ISO), and peer-reviewed literature on digital health validation.

### 36. Failure cases, litigation or reputational patterns, and lessons from discontinued or controversial digital-health products

The failure of high-profile digital health startups like Pear Therapeutics and Babylon Health reveals that clinical validation and technological hype are insufficient without sustainable unit economics, seamless clinical workflow integration, and clear reimbursement pathways. Furthermore, FTC enforcement actions against apps like Flo Health and GoodRx demonstrate that aggressive monetization of sensitive health data via third-party advertising SDKs carries severe regulatory and reputational risks. A successful personal health "second brain" must prioritize infrastructure, workflow compatibility, and strict data privacy over rapid scaling and unproven AI claims.

**Evidence quality:** High — Findings are grounded in FTC enforcement actions, bankruptcy filings, and detailed post-mortem analyses from credible industry publications.

## Most-cited domains

| Domain | Citations |
|---|---:|
| bearable.app | 14 |
| guavahealth.com | 13 |
| careclinic.io | 7 |
| headsuphealth.com | 7 |
| pmc.ncbi.nlm.nih.gov | 7 |
| seqster.com | 4 |
| apps.apple.com | 4 |
| reddit.com | 4 |
| human.health | 4 |
| fda.gov | 4 |
| makevisible.com | 3 |
| picnichealth.com | 3 |
| onerecord.com | 3 |
| patientslikeme.com | 3 |
| stuffthatworks.health | 3 |
| academic.oup.com | 3 |
| aelivra.co | 3 |
| choosingtherapy.com | 3 |
| exist.io | 3 |
| mysymptoms.net | 3 |
| crowncounseling.com | 3 |
| sciencedirect.com | 3 |
| arxiv.org | 3 |
| researchgate.net | 2 |
| frontiersin.org | 2 |
| functionhealth.com | 2 |
| resources.selfdecode.com | 2 |
| flaredown.com | 2 |
| play.google.com | 2 |
| openhumans.org | 2 |
| practicebetter.io | 2 |
| fullscript.com | 2 |
| rupahealth.com | 2 |
| forum.obsidian.md | 2 |
| link.springer.com | 2 |
| mcdermottlaw.com | 2 |
| themomentum.ai | 2 |
| ico.org.uk | 2 |
| gov.uk | 2 |
| oaic.gov.au | 2 |
| tga.gov.au | 2 |
| dl.acm.org | 1 |
| rockhealth.com | 1 |
| grandviewresearch.com | 1 |
| straitsresearch.com | 1 |
| hdsr.mitpress.mit.edu | 1 |
| psb.stanford.edu | 1 |
| mozillafoundation.org | 1 |
| intuitionlabs.ai | 1 |
| help.human.health | 1 |
