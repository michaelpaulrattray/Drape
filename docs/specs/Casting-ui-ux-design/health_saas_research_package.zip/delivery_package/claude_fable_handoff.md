# Claude Fable Handoff Prompt

## Objective

Create the final evidence-based operating plan for a personal health SaaS using the attached **Personal Health “Second Brain” SaaS: Comprehensive Market, Competitor, Gap, Product, and Validation Research** as the authoritative research input.

Do **not** simply restate the original idea. The research concludes that a broad “root-cause second brain” is crowded, medically risky, and technically over-scoped. The plan must convert the opportunity into a staged validation program and preserve every distinction between a confirmed fact, an unverified market gap, and an assumption.

## Recommended concept to plan

> **A provenance-first, safety-conservative personal health evidence and visit-preparation workspace that turns fragmented longitudinal data into a trustworthy timeline, inspectable associations, competing evidence-linked hypotheses, and a concise clinician-reviewable packet—without diagnosing, ranking root causes, or recommending treatment.**

The recommended initial cohort is adults with post-viral illness, dysautonomia/POTS, exertion intolerance or fatigue, and overlapping multi-system symptoms. The initial job is **complex-care visit preparation**, not disease diagnosis. The first operating vehicle is a human-assisted concierge service; self-service software follows only after the value, report format, safety boundary, and willingness to pay are validated.

## Required plan structure

Produce the plan in the following order.

### 1. Decision memo

State the decision to pursue, defer, or reject each strategic option. The default recommendation from the research is:

| Option | Default decision |
|---|---|
| A. Concierge evidence-and-visit service | Pursue first |
| B. Consumer self-service workspace | Conditional on Option A gates |
| C. Clinic-sponsored workflow | Conditional on clinician acceptance and buyer discovery |
| Broad root-cause or diagnostic platform | Reject for initial plan |
| Employer individual-level analytics | Defer and restrict |
| Advertising or health-data brokerage | Reject |

### 2. Problem, user, and job-to-be-done

Define one primary user, one trigger, one job, and one hero output. Include the current workaround, why it fails, and evidence still required. Do not use “everyone with a chronic condition” as the initial user.

### 3. Market and competitor map

Use the research dossier’s category map and competitor matrix. Explicitly state that aggregation, tracking, correlations, AI summaries, evidence-oriented pathways, and doctor reports already exist. Label every proposed whitespace claim as **confirmed absence**, **not publicly verified**, or **hypothesis requiring product testing**. Do not claim a competitor lacks a function simply because its public site did not mention it.

### 4. Positioning and messaging

Use **personal health evidence and visit-preparation workspace** as the working category. The message should emphasize reliable story reconstruction, provenance, uncertainty, and clinician questions. Avoid “root cause,” “diagnose,” “cure,” “reverse,” “prevent,” “personalized treatment,” “doctor replacement,” and “AI knows your body better.”

### 5. Concierge validation program

Design a 6–10 week pilot for 20–30 people with real upcoming visits. Specify recruitment, inclusion/exclusion criteria, consent, source-data handling, human verification, clinician involvement, payment tests, adverse-event handling, and quantitative/qualitative measures. Include a process map from intake to verified packet to post-visit follow-up.

### 6. Validation gates

Retain or explicitly revise the dossier’s proposed gates for:

| Gate | Required measure |
|---|---|
| Problem intensity | Independent description of recurring high-friction timeline or visit-preparation work |
| Accuracy | Material factual correction rate and critical-field extraction accuracy |
| Clinician usefulness | Usefulness score, omission review, and summary-page review time |
| Burden | Active daily effort, setup time, and week-eight engagement |
| Understanding | Ability to distinguish observation, association, and causation |
| Willingness to pay | Real payment for a one-time packet and recurring workspace |
| AI safety | Zero unblocked high-severity diagnosis, treatment, dangerous restriction, emergency reassurance, or fabricated-citation failures |
| Anxiety and wellbeing | No meaningful deterioration attributable to product use |
| Channel economics | Acquisition, onboarding, support, contribution margin, and payback |

For each gate, identify who owns measurement, when it is reviewed, and what decision follows pass, partial pass, or fail.

### 7. MVP definition

The MVP must include only the minimum validated workflow: timeline, selected passive and clinical imports, document verification, provenance, sparse check-ins, descriptive and lag-aware associations, evidence cards, non-ranked hypotheses, clinician packet, export/deletion/consent/access controls, and evaluation infrastructure.

Explicitly exclude diagnosis, disease probability, ranked root causes, treatment/test/supplement recommendations, emergency triage, nationwide record-completeness claims, open community diagnosis matching, employer individual analytics, and health-data monetization.

### 8. Safety, regulatory, and privacy plan

Create a function-by-function claims inventory and assign each function a U.S. FDA, FTC/HHS, state privacy, and liability review. State that legal counsel is required and that the plan is not legal advice. Include a launch-jurisdiction decision; do not assume global release.

Define the evidence ladder:

1. Observation.
2. Association.
3. Hypothesis.
4. Low-risk experiment candidate.
5. Clinician-reviewed N-of-1 protocol.
6. Individual, context-specific result.

Define prohibited AI outputs, deterministic red-flag redirects, citation-entailment testing, contradiction handling, prompt-injection defense, model-change regression testing, incident review, and post-market monitoring. Include psychological safety and compulsive-tracking controls.

Treat privacy as architecture. Include data minimization, purpose-bound consent, research opt-in, no advertising SDKs, vendor/subprocessor review, short-lived access, auditable support access, export, deletion, breach response, and an honest encryption claim. Do not claim end-to-end encryption if cloud AI receives plaintext.

### 9. Technical plan

Propose a mobile-first capture client and web review workspace. Use a FHIR-compatible event-oriented model while preserving original source data. Describe ingestion order: HealthKit/Health Connect; authorized FHIR; structured files; verified OCR; manual entry. Require source, original and normalized values, units, timestamps, institution/device, parser version, consent scope, confidence, verification, and correction history for every datum.

Separate verified facts, user observations, hypotheses, and medical evidence in the knowledge graph. Specify a versioned evaluation system for ingestion, factuality, citation entailment, safety, bias, privacy, accessibility, and usability. Do not specify vendors as irrevocable choices before technical spikes.

### 10. Business model and pricing experiments

Model a free organizational layer, a one-time paid visit packet, a recurring evidence workspace, and later clinic sponsorship. Treat prices as experiments. Separate D2C, clinic, advocacy, employer, and research economics. Do not assume data monetization or employer surveillance. Build the financial model bottom-up from reachable channels, observed conversion, support cost, retention, and payer type.

### 11. Go-to-market

Sequence condition-community co-design, concierge recruitment, clinician validation, closed product pilots, paid cohort launch, and controlled cohort expansion. Compensate community and clinician contributors. Require explicit consent for stories and testimonials. Define channel experiments and stop conditions.

### 12. Roadmap, team, and budget

Use milestone-based stages rather than a feature calendar. The initial stages are discovery/governance, concierge validation, technical spikes, closed MVP, paid cohort launch, and adjacent expansion. For each stage, provide team roles, external advisors, budget range, deliverables, risks, and decision gate. Preserve uncertainty in duration and cost.

### 13. Risk register and kill criteria

Include clinical harm, medical-device classification, privacy breach, ingestion error, logging fatigue, clinician rejection, weak willingness to pay, health anxiety, bias, and competitive response. Every risk needs an owner, early warning, prevention, response, and explicit pause/kill condition.

### 14. Assumption ledger

Create a table with columns for assumption, why it matters, current evidence, confidence, test, owner, deadline, pass threshold, and consequence of failure. At minimum include segment choice, report value, clinician acceptance, evidence comprehension, willingness to pay, clinic sponsorship, retrieval quality, ingestion accuracy, regulatory boundary, and anxiety impact.

### 15. Final recommendation

Conclude with a direct recommendation for the next 30, 60, and 90 days. Do not recommend substantial platform engineering before the concierge artifact and safety boundary pass their gates.

## Evidence and citation rules

Use the dossier’s inline citations and reference list. Prefer primary sources. Do not cite market-report numbers as if they were audited. Label community comments and reviews as qualitative anecdotes. Attach a research-gap appendix listing every material claim that still requires customer research, product testing, legal advice, or clinical review.

## Quality constraints

The plan must be specific enough to operate but conservative enough to be credible. It must not imply that an AI system can infer root causes from observational health data. It must not treat a disclaimer as a safety control. It must not treat HIPAA as the whole privacy landscape. It must not treat retrieval-augmented generation as a guarantee against hallucination. It must not present the large chronic-condition population as the paying market.

## Acceptance test

Reject and rewrite the plan if any of the following is true:

| Failure | Required correction |
|---|---|
| The MVP contains diagnosis, root-cause ranking, or treatment recommendations | Remove the function and replace it with evidence-linked questions. |
| The plan claims generic aggregation or correlations are unique | Correct the competitor analysis. |
| The market model multiplies a prevalence denominator by a subscription price | Rebuild it from channels and observed conversion. |
| The plan assumes complete EHR connectivity | Add the multi-route ingestion model and coverage disclosure. |
| The safety section relies on disclaimers | Add function constraints, hard blocks, evaluation, and monitoring. |
| Privacy is only a policy statement | Add data-flow, consent, access, deletion, vendor, and incident architecture. |
| Competitor gaps are asserted without qualification | Relabel as not publicly verified and add validation. |
| The roadmap begins with a broad software build | Reorder it around concierge validation and decision gates. |

